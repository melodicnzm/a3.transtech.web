import { Injectable } from '@angular/core';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class ApiHttpClient extends HttpClient {
  public baseUrl: string;

  public constructor(handler: HttpHandler) {
    super(handler);

    // Get base url from wherever you like, or provision ApiHttpClient in your AppComponent or some other high level
    // component and set the baseUrl there.
    this.baseUrl = 'http://localhost:3001/api';
  }

  public get<T>(url: string, options?: Object): Observable<T> {
    url = this.baseUrl + url;
    return super.get<T>(url, options);
  }

  public post<T> (url: string, payload: any, options?: Object): Observable<T> {
    url = this.baseUrl + url;
    return super.post<T>(url, payload, options);
  }

  public put<T> (url: string, payload: T, options?: Object): Observable<T> {
    url = this.baseUrl + url;
    return super.put<T>(url, payload, options);
  }

  public delete<T> (url: string, options?: Object): Observable<T> {
    url = this.baseUrl + url;
    return super.delete<T>(url, options);
  }
}
