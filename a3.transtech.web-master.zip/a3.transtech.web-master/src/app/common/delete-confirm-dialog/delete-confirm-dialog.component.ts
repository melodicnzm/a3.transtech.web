import { Component } from '@angular/core';
import { NbDialogRef } from '@nebular/theme';


@Component({
  selector: 'ngx-delete-confirm-dialog',
  templateUrl: './delete-confirm-dialog.component.html',
  styleUrls: ['./delete-confirm-dialog.component.scss'],
})
export class DeleteConfirmDialogComponent  {

  constructor(protected ref: NbDialogRef<DeleteConfirmDialogComponent>) {}

  message: String;

  cancel() {
    this.ref.close(false);
  }

  submit() {
    this.ref.close(true);
  }

}
