import { NgModule } from '@angular/core';
import { A3DatepickerComponent } from './a3-datepicker/a3-datepicker.component';
import { NbDatepickerModule,
  NbInputModule,
  NbButtonModule,
  NbIconModule,
  NbTooltipModule,
  NbDialogModule,
  NbCardModule } from '@nebular/theme';
import { FormsModule } from '@angular/forms';
import { FileUploadModule } from 'ng2-file-upload';
import { A3FileUploadComponent } from './a3-file-upload/a3-file-upload.component';
import { CommonModule } from '@angular/common';
import { DuplicateCheckComponent } from './duplicate-check/duplicate-check.component';
import { DeleteConfirmDialogComponent } from './delete-confirm-dialog/delete-confirm-dialog.component';

@NgModule({
  imports: [
    NbDatepickerModule,
    FormsModule,
    NbInputModule,
    NbIconModule,
    NbButtonModule,
    NbTooltipModule,
    FileUploadModule,
    CommonModule,
    NbCardModule,
    NbIconModule,
    NbDialogModule.forChild(),
  ],
  declarations: [A3DatepickerComponent, A3FileUploadComponent, DuplicateCheckComponent, DeleteConfirmDialogComponent],
  exports: [A3DatepickerComponent, A3FileUploadComponent, DuplicateCheckComponent, DeleteConfirmDialogComponent],
  entryComponents: [ DuplicateCheckComponent, DeleteConfirmDialogComponent ],
})
export class A3CommonModule { }
