import { Component, OnInit, Input, Output, EventEmitter, TemplateRef, ViewChild } from '@angular/core';
import { NbCalendarRange, NbDialogService } from '@nebular/theme';

@Component({
  selector: 'ngx-datepicker',
  templateUrl: './a3-datepicker.component.html',
  styleUrls: ['./a3-datepicker.component.scss'],
})
export class A3DatepickerComponent implements OnInit {
  @Input() placeholder: String = '';
  @Input() toolText: String = '';
  @Input() startDate: Date;
  @Input() endDate: Date;
  @Output() startDateChange: EventEmitter<Date>  = new EventEmitter<Date>();
  @Output() endDateChange: EventEmitter<Date> = new EventEmitter<Date>();
  range: NbCalendarRange<Date>;
  @ViewChild('dialog' , { static: false }) dialog: TemplateRef<any>;

  constructor(private dialogService: NbDialogService) { }

  ngOnInit() {
    this.range = {start: this.startDate, end: this.endDate};

  }
  onRdangeChange(data) {
    const currentDate = new Date();
    if (data.start !== undefined && data.end !== undefined) {
      if (!(currentDate > data.start && currentDate < data.end)) {
        this.dialogService.open(this.dialog, { context: 'OOPS!' });
      }
    }
    this.startDateChange.emit(data.start);
    this.endDateChange.emit(data.end);
  }
}
