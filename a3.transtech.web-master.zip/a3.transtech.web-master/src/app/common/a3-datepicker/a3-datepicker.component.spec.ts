import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { A3DatepickerComponent } from './a3-datepicker.component';

describe('A3DatepickerComponent', () => {
  let component: A3DatepickerComponent;
  let fixture: ComponentFixture<A3DatepickerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ A3DatepickerComponent ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(A3DatepickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
