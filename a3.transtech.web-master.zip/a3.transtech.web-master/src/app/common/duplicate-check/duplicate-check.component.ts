import { Component } from '@angular/core';
import { NbDialogRef } from '@nebular/theme';


@Component({
  selector: 'ngx-duplicate-check',
  templateUrl: './duplicate-check.component.html',
  styleUrls: ['./duplicate-check.component.scss'],
})
export class DuplicateCheckComponent  {

  constructor(protected ref: NbDialogRef<DuplicateCheckComponent>) {}

  message: String;

  onOk() {
    this.ref.close(false);
  }

}
