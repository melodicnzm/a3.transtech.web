import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';
import { UploadedFiles, OperationsService } from '../../pages/operations/operations.service';
import { saveAs } from 'file-saver';

@Component({
  selector: 'ngx-file-upload',
  templateUrl: './a3-file-upload.component.html',
  styleUrls: ['./a3-file-upload.component.scss'],
})

export class A3FileUploadComponent implements OnInit {

  @Input() uri: string = '';
  @Input() toolText: String = '';
  @Input() buttonName: string = '';
  @Input() attachmentList:  Array<UploadedFiles>;
  @Output() attachmentListChange = new EventEmitter<Array<UploadedFiles>>();

  public uploader: FileUploader;

  constructor(private service: OperationsService) {  }

  ngOnInit() {
    this.uploader = new FileUploader({url: this.uri});
    this.uploader.onAfterAddingFile = (file) => {
      file.withCredentials = false;
      this.uploader.queue.find(x => x === file).upload();
    };
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
        if (response) {
          this.attachmentList.push(JSON.parse(response));
          this.attachmentListChange.emit(this.attachmentList);
        }
    };
   }

  deleteUploadedFile(file) {
    this.service.deleteFile(file.uploadname).subscribe(x => {
        const attachmentIndex = this.attachmentList.findIndex(a => a.uploadname === file.uploadname);
        this.attachmentList.splice(attachmentIndex, 1);
        this.attachmentListChange.emit(this.attachmentList);
      });
  }

  download(file) {
    this.service.downloadFile(file.uploadname).subscribe(
            data => saveAs(data, file.uploadname),
            error => console.error(error),
        );
  }

}
