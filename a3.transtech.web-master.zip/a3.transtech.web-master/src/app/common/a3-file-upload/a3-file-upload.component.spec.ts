import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { A3FileUploadComponent } from './a3-file-upload.component';

describe('A3FileUploadComponent', () => {
  let component: A3FileUploadComponent;
  let fixture: ComponentFixture<A3FileUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ A3FileUploadComponent ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(A3FileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
