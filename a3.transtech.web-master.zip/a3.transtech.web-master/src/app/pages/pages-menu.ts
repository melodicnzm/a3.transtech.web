/*
 * Copyright (c) Akveo 2019. All Rights Reserved.
 * Licensed under the Single Application / Multi Application License.
 * See LICENSE_SINGLE_APP / LICENSE_MULTI_APP in the 'docs' folder for license information on type of purchased license.
 */

import { NbMenuItem } from '@nebular/theme';
import { Observable, of } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class PagesMenu {

  getMenu(): Observable<NbMenuItem[]> {
    const dashboardMenu: NbMenuItem[] = [
      {
        title: 'Dashboard',
        icon: 'home-outline',
        link: '/pages/dashboard',
        home: true,
        children: undefined,
      },
    ];

    const menu: NbMenuItem[] = [
      {
        title: 'FEATURES',
        group: true,
      },
      {
        title: 'Operations',
        icon: 'edit-2-outline',
        children: [
          {
            title: 'Transporter',
            link: '/pages/operations/transporter-master',
          },
          {
            title: 'Customer',
            link: '/pages/operations/customer',
          },
          {
            title: 'Vehicle',
            link: '/pages/operations/vehicle',
          },
          {
            title: 'Vehicle Type',
            link: '/pages/operations/vehicleType',
          },
          {
            title: 'Owner',
            link: '/pages/operations/owner',
          },
          {
            title: 'Driver',
            link: '/pages/operations/driver',
          },
          {
            title: 'Vendor',
            link: '/pages/operations/vendor',
          },
          {
            title: 'Location',
            link: '/pages/operations/location-master',
          },
          {
            title: 'Docket',
            link: '/pages/docet-entry-master',
            children: [
              {
                title: 'Full Load',
                link: '/pages/operations/docket-details-list',
              },
            ],
          },
          {
            title: 'Forwarding',
            link: '/pages/forwarding',
            children: [
              {
                title: 'TC/Manefistation',
                link: '/pages/forwarding/manefastation',
              },
              {
              title: 'Trip Hire Contract',
              link: '/pages/forwarding/trip-hire-contract',
              },
            ],
          },
          {
            title: 'POD Updation',
            link: '/pages/pod-updation',
          },
        ],
      },
      {
        title: 'Inventory',
        icon: 'layout-outline',
        children: [
          {
            title: 'Inventory',
            link: '/pages/inventory/inventory',
          },
          {
            title: 'Letter Head',
            // link: '/pages/operations/owner',
          },
          {
            title: 'Voucher',
            // link: '/pages/operations/owner',
          },
        ],
      },
    ];

    return of([...dashboardMenu, ...menu]);
  }
}
