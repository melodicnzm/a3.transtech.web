import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Location, Locality, LocationService } from '../location.service';

@Component({
  selector: 'ngx-location-master',
  templateUrl: './location-master.component.html',
  styleUrls: ['./location-master.component.scss'],
})
export class LocationMasterComponent implements OnInit {
  options = {};
  location: Location;
  stateList: String[] = [];
  constructor(private service: LocationService, private route: ActivatedRoute) {

    this.location = new Location();
    this.stateList = new Array<String>();
    this.location.locatity = new Array<Locality>();
    this.location.locatity.push({name: '', longitude: 0, latitude: 0}) ;
  }

  ngOnInit() {
    const requestedLocation = this.route.snapshot.paramMap.get('id');
    if (requestedLocation) {
      this.service.Get(requestedLocation).subscribe(response => {
        this.location = response;
      });
    }
    // const allStateList = this.service.GetStates();
  }

}
