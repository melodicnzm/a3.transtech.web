import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpService } from '../../../@core/backend/common/api/http.service';

export interface Locality {
  name: String;
  longitude: Number;
  latitude: Number;
}

export class Location {
  _id: String;
  country: String;
  pin: Number;
  state: String;
  district: String;
  taluka: String;
  locatity: Array<Locality>;
}

@Injectable()
export class LocationService {

  constructor(private api: HttpService) { }

  GetAll(): Observable<Location[]> {
    return this.api.get('/location');
  }

  Get(id: string): Observable<Location> {
    return this.api.get(`/location/${id}`);
  }

  Save(location: Location): Observable<Location> {
    return this.api.post('/location/', location);
  }

  Update(location: Location): Observable<Location> {
    return this.api.put('/location/', location);
  }

  Delete(id: string): Observable<Location> {
    return this.api.delete(`/location/${id}`);
  }

  GetByPin(pin: string): Observable<Location> {
    return this.api.get(`/location/location/${pin}`);
  }

  GetByPinAndLocation(pin: string, loc: string): Observable<Location> {
    return this.api.get(`/location/location/${pin}/${loc}`);
  }

  GetByLocation(loc: string): Observable<Location> {
    return this.api.get(`/location/locationName/${loc}`);
  }

  GetStates(): Observable<String[]> {
    return this.api.get(`/location/distinct/state`);
  }
}
