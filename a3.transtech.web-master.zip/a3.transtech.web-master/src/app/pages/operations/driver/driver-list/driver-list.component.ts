import { Component } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';

import { DriverService } from '../driver.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DeleteConfirmDialogComponent } from '../../../../common/delete-confirm-dialog/delete-confirm-dialog.component';
import { NbDialogService } from '@nebular/theme';


@Component({
  selector: 'ngx-driver-list',
  templateUrl: './driver-list.component.html',
  styleUrls: ['./driver-list.component.scss'],
})
export class DriverListComponent {

  settings = {
    columns: {
      driverName: {
        title: 'Driver Name' ,
        type: 'string',
      },
      phone1: {
        title: 'Phone Number 1',
        type: 'string',
      },
      phone2: {
        title: 'Phone Number 2',
        type: 'string',
      },
      registrationDate: {
        title: 'Registration Date',
        type: 'Date',
      },
      lastUpdationDate: {
        title: 'Last Updation Date',
        type: 'Date',
      },
    },
    mode: 'external',
    add: {
      confirmCreate: true,
      addButtonContent: '<i class="nb-plus"></i>',
    },
    edit: {
      confirmEdit: true,
      editButtonContent: '<i class="nb-edit"></i>',
    },
    delete: {
      confirmDelete: true,
      deleteButtonContent: '<i class="nb-trash"></i>',
    },
  };

  source: LocalDataSource = new LocalDataSource();

  constructor(private service: DriverService,
    private router: Router,
    private route: ActivatedRoute,
    private dialogService: NbDialogService) {
    const data = this.service.GetAll();
    data.subscribe(val => this.source.load(val));
  }

  onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }

  onCreate(event): void {
    this.router.navigate(['../driver-master'], { relativeTo: this.route });
  }
  onEdit(event): void {
    this.router.navigate(['../driver-master', { id: event.data._id }], { relativeTo: this.route });
  }
  onDelete(event): void {
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete this Driver?',
      },
    })
    .onClose.subscribe(confirm => {
      if (confirm) {
        if (event.data.driverPhoto.length) {
          // Delete uploaded files
          event.data.driverPhoto.forEach(file => {
            this.service.deleteFile(file.uploadname).subscribe(x => {
            });
          });
        }
        if (event.data.panCardPhoto.length) {
          // Delete uploaded files
          event.data.panCardPhoto.forEach(file => {
            this.service.deleteFile(file.uploadname).subscribe(x => {
            });
          });
        }
        if (event.data.adharCardPhoto !== undefined) {
          if (event.data.adharCardPhoto.length) {
            // Delete uploaded files
            event.data.adharCardPhoto.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          }
        }
        if (event.data.licence.length) {
          // Delete uploaded files
          event.data.licence.forEach(eachlicence => {
            eachlicence.licencePhoto.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          });
        }
        this.service.Delete(event.data._id).subscribe(response => {
          const data = this.service.GetAll();
          data.subscribe(val => this.source.load(val));
        });
      }
    });
  }
}
