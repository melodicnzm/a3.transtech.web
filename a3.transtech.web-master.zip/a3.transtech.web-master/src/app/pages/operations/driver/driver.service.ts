import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { HttpService } from '../../../@core/backend/common/api/http.service';


export interface UploadedFiles {
  originalname: string;
  uploadname: string;
}

export interface Address {
  houseNumber: string;
  buildingName: string;
  locality: string;
  area: string;
  district: string;
  state: string;
  country: string;
  pin: string;
}

export interface LicenceDetails {
  licenceNumber: string;
  issuedFromState: string;
  validityFrom: Date;
  validityTo: Date;
  licencePhoto: Array<UploadedFiles>;
}

export class Driver {
  _id: string;
  driverName: string;
  driverPhoto: Array<UploadedFiles>;
  phone1: string;
  phone2: string;
  address: Array<Address>;
  licence: Array<LicenceDetails>;
  panCardPhoto: Array<UploadedFiles>;
  adharCardPhoto: Array<UploadedFiles>;
  registrationDate: Date;
  lastUpdationDate: Date;
  registeredBy: Number;
  updatedBy: Number;
}

@Injectable()
export class DriverService {

  constructor(private api: HttpService) { }

  GetAll(): Observable<Driver[]> {

    return this.api
      .get('/driver');
  }

  Get(id: string): Observable<Driver> {
    return this.api.get(`/driver/${id}`);
  }

  Save(driver: Driver): Observable<Driver> {
    return this.api.post('/driver/', driver);
  }

  Update(driver: Driver): Observable<Driver> {
    return this.api.put('/driver/', driver);
  }

  Delete(id: string): Observable<Driver> {
    return this.api.delete(`/driver/${id}`);
  }

  deleteFile(file: String) {
    return this.api.post('/upload/delete', { filename: file });
  }

  // Driver already exists or not
  Exists(driver: Driver): Observable<Driver> {
    return this.api.get(`/driver/exists/${driver.driverName}/${driver.phone1}`);
  }
}
