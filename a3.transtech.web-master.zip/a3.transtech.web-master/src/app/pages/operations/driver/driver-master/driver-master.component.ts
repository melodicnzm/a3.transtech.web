import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { DriverService, Driver, Address, LicenceDetails, UploadedFiles } from '../driver.service';

import { DeleteConfirmDialogComponent } from '../../../../common/delete-confirm-dialog/delete-confirm-dialog.component';
import { NbDialogService } from '@nebular/theme';
import { LocationService } from '../../location/location.service';
import { DuplicateCheckComponent } from '../../../../common/duplicate-check/duplicate-check.component';


@Component({
  selector: 'ngx-driver-master',
  templateUrl: './driver-master.component.html',
  styleUrls: ['./driver-master.component.scss'],
})
export class DriverMasterComponent implements OnInit {

  driver: Driver;
  statesList: Array<String>;

  submitted: Boolean;
  // define the constant url we would be uploading to.
  uri = 'http://localhost:3001/api/upload';

  constructor(private service: DriverService,
    private router: Router,
    private route: ActivatedRoute,
    private dialogService: NbDialogService,
    private location: LocationService) {
    this.driver = new Driver();
    this.statesList = new Array<String>();
    this.driver.driverPhoto = new Array<UploadedFiles>();
    this.driver.adharCardPhoto = new Array<UploadedFiles>();
    this.driver.panCardPhoto = new Array<UploadedFiles>();

    this.driver.address = new Array<Address>();
    this.driver.address.push({
      houseNumber: '',
      buildingName: '',
      locality: '',
      area: '',
      district: '',
      state: '',
      country: '',
      pin: '',
    });

    this.driver.licence = new Array<LicenceDetails>();
    this.driver.licence.push({
      licenceNumber: '',
      issuedFromState: '',
      validityFrom: new Date(),
      validityTo: new Date(),
      licencePhoto: new Array<UploadedFiles>(),
    });
  }

  ngOnInit() {
    const requestedDriver = this.route.snapshot.paramMap.get('id');
    if (requestedDriver) {
      this.service.Get(requestedDriver).subscribe(response => {
        this.driver = response;
        if (this.driver.licence.length === 0) {
          this.driver.licence.push({
            licenceNumber: '',
            issuedFromState: '',
            validityFrom: new Date(),
            validityTo: new Date(),
            licencePhoto: new Array<UploadedFiles>(),
          });
        }
      });
    }
    const states = this.location.GetStates();
    if (states) {
      states.subscribe(val => {
        this.statesList = val;
      });
    }
  }

  addNewAddress() {
    this.driver.address.push({
      houseNumber: '',
      buildingName: '',
      locality: '',
      area: '',
      district: '',
      state: '',
      country: '',
      pin: '',
    });
  }
  deleteAddress(address, event) {
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          const deleteIndex = this.driver.address.indexOf(address);
          this.driver.address.splice(deleteIndex, 1);
        }
      });
  }

  addNewLicence() {
    this.driver.licence.push({
      licenceNumber: '',
      issuedFromState: '',
      validityFrom: new Date(),
      validityTo: new Date(),
      licencePhoto: new Array<UploadedFiles>(),
    });
  }
  deleteLicence(licence) {
    const deleteIndex = this.driver.licence.indexOf(licence);
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          if (licence.licencePhoto.length) {
            // Delete uploaded files
            licence.licencePhoto.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          }
          this.driver.licence.splice(deleteIndex, 1);
        }
      });
  }

  onSave(form) {
    this.service.Exists(this.driver).subscribe(response => {
      if (response) {
        this.dialogService.open(DuplicateCheckComponent, {
          context: {
            message: 'Driver Already Registered!',
          },
        })
          .onClose.subscribe(confirm => {
            return false;
          });
      } else {
        if (form.valid) {
          if (this.driver._id) {
            this.driver.lastUpdationDate = new Date();
            this.service.Update(this.driver).subscribe(res => {
              this.router.navigate(['../driver'], { relativeTo: this.route });
            });
          } else {
            this.service.Save(this.driver).subscribe(res => {
              this.router.navigate(['../driver'], { relativeTo: this.route });
            });
          }
        }
      }
    });
  }

  onCancel() {
    this.router.navigate(['../driver'], { relativeTo: this.route });
  }
}
