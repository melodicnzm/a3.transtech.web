import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OperationsComponent } from './operations.component';
import { VehicalMasterComponent } from './vehicle-master/vehical-master.component';
import { VehicleListComponent } from './vehicle-list/vehicle-list.component';
import { OwnerListComponent } from './Owner/owner-list/owner-list.component';
import { OwnerMasterComponent } from './Owner/owner-master/owner-master.component';
import { VendorMasterComponent } from './Vendor/vendor-master/vendor-master.component';
import { VendorListComponent} from './Vendor/vendor-list/vendor-list.component';
import { VehicleTypeComponent } from './vehicle-type/vehicle-type.component';
import { LocationMasterComponent } from './location/location-master/location-master.component';
import { TransporterMasterComponent } from './transporter/transporter-master/transporter-master.component';
import { CustomerListComponent } from './customer/customer-list/customer-list.component';
import { CustomerMasterComponent } from './customer/customer-master/customer-master.component';
import { DriverMasterComponent } from './driver/driver-master/driver-master.component';
import { DriverListComponent } from './driver/driver-list/driver-list.component';
import { DocketDetailsListComponent } from './docket-details/docket-details-list/docket-details-list.component';
import { DocketDetailsComponent } from './docket-details/docket-details/docket-details.component';


const routes: Routes = [{
  path: '',
  component: OperationsComponent,
  children: [
    {
      path: 'customer-master',
      component: CustomerMasterComponent,
    },
    {
      path: 'customer',
      component: CustomerListComponent,
    },
    {
      path: 'vehical-master',
      component: VehicalMasterComponent,
    },
    {
      path: 'vehicle',
      component: VehicleListComponent,
    },
    {
      path: 'owner-master',
      component: OwnerMasterComponent,
    },
    {
      path: 'owner',
      component: OwnerListComponent,
    },
    {
      path: 'driver-master',
      component: DriverMasterComponent,
    },
    {
      path: 'driver',
      component: DriverListComponent,
    },
    {
      path: 'vendor-master',
      component: VendorMasterComponent,
    },
    {
      path: 'vendor',
      component: VendorListComponent,
    },
    {
      path: 'vehicleType',
      component: VehicleTypeComponent,
    },
    {
      path: 'location-master',
      component: LocationMasterComponent,
    },
    {
      path: 'transporter-master',
      component: TransporterMasterComponent,
    },
    {
      path: 'docket-details-list',
      component: DocketDetailsListComponent,
    },
    {
      path: 'docket-details',
      component: DocketDetailsComponent,
    },

  ],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OperationsRoutingModule {
}
