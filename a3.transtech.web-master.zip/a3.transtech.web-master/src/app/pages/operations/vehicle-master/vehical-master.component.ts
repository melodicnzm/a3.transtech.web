import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OperationsService, Vehicle, Insurance, Puc, Permit, FitnessCertificate, UploadedFiles } from '../operations.service';
import { VehicleType } from '../vehicle-type/vehicle-type.service';
import { LocationService } from '../location/location.service';

// For Delete Confirmation
import { DeleteConfirmDialogComponent } from '../../../common/delete-confirm-dialog/delete-confirm-dialog.component';
import { NbDialogService, NbWindowService } from '@nebular/theme';
import { DuplicateCheckComponent } from '../../../common/duplicate-check/duplicate-check.component';


@Component({
  selector: 'ngx-vehicle-master',
  styleUrls: ['./vehical-master.component.scss'],
  templateUrl: './vehical-master.component.html',
})

export class VehicalMasterComponent implements OnInit {

  // define the constant url we would be uploading to.
  uri = 'http://localhost:3001/api/upload';

  date: Date;
  error: string;
  statesList: Array<String>;
  vehicle: Vehicle;
  vehicleTypeList: Array<VehicleType>;
  submitted: Boolean;

  // TODO static must be false as of Angular 9.0.0
  @ViewChild('contentTemplate', { static: false }) contentTemplate: TemplateRef<any>;


  constructor(private windowService: NbWindowService,
    private service: OperationsService,
    private router: Router,
    private route: ActivatedRoute,
    private dialogService: NbDialogService,
    private location: LocationService) {

    this.vehicle = new Vehicle();
    this.statesList = new Array<String>();
    this.vehicleTypeList = new Array<VehicleType>();
    this.vehicle.insurance = new Array<Insurance>();
    this.vehicle.vehiclePhoto = new Array<UploadedFiles>();
    this.vehicle.rcBookPhoto = new Array<UploadedFiles>();
    this.vehicle.insurance.push({
      companyName: '',
      insuranceNumber: '',
      validityFrom: this.date,
      validityTo: this.date,
      insurancePhoto: new Array<UploadedFiles>(),
    });

    this.vehicle.puc = new Array<Puc>();
    this.vehicle.puc.push({
      pucNumber: '',
      validityFrom: this.date,
      validityTo: this.date,
      pucPhoto: new Array<UploadedFiles>(),
    });

    this.vehicle.fitnessCertificate = new Array<FitnessCertificate>();
    this.vehicle.fitnessCertificate.push({
      certificateNumber: '',
      validityFrom: this.date,
      validityTo: this.date,
      fitnessCertificatePhoto: new Array<UploadedFiles>(),
    });

    this.vehicle.permit = new Array<Permit>();
    this.vehicle.permit.push({
      permitType: '',
      validityFrom: this.date,
      validityTo: this.date,
      states: [],
      permitPhoto: new Array<UploadedFiles>(),
    });

  }

  ngOnInit() {
    const requestedVehicle = this.route.snapshot.paramMap.get('id');
    if (requestedVehicle) {
      this.service.Get(requestedVehicle).subscribe(response => {
        this.vehicle = response;
      });
    }
    const vehicleTypeData = this.service.GetAllVehicleType();
    if (vehicleTypeData) {
      vehicleTypeData.subscribe(val => {
        val.unshift({ _id: '0', vehicleType: 'Vehicle Type', capacity: 0, description: '' });
        this.vehicle.vehicleType = 'Vehicle Type';
        this.vehicleTypeList = val;
      });
    }

    const states = this.location.GetStates();
    if (states) {
      states.subscribe(val => {
        this.statesList = val;
      });
    }
  }

  viewImage(index) {
    this.windowService.open(
      this.contentTemplate,
      { title: 'Window with backdrop', hasBackdrop: true },
    );
  }

  changeCapacity() {
    this.vehicleTypeList.forEach(value => {
      if (value.vehicleType === this.vehicle.vehicleType) {
        this.vehicle.loadingCapacity = value.capacity;
      }
    });
  }

  addNewInsurance() {
    this.vehicle.insurance.push({
      companyName: '',
      insuranceNumber: '',
      validityFrom: this.date,
      validityTo: this.date,
      insurancePhoto: new Array<UploadedFiles>(),
    });
  }
  deleteInsurance(insurance) {
    const deleteIndex = this.vehicle.insurance.indexOf(insurance);
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          if (insurance.insurancePhoto.length) {
            // Delete uploaded files
            insurance.insurancePhoto.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          }
          // Delete insurance
          this.vehicle.insurance.splice(deleteIndex, 1);
        }
      });
  }

  addNewFitness() {
    this.vehicle.fitnessCertificate.push({
      certificateNumber: '',
      validityFrom: this.date,
      validityTo: this.date,
      fitnessCertificatePhoto: new Array<UploadedFiles>(),
    });
  }
  deleteFitness(fitness) {
    const deleteIndex = this.vehicle.fitnessCertificate.indexOf(fitness);
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          if (fitness.fitnessCertificatePhoto.length) {
            // Delete uploaded files
            fitness.fitnessCertificatePhoto.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          }
          this.vehicle.fitnessCertificate.splice(deleteIndex, 1);
        }
      });
  }
  addNewPermit() {
    this.vehicle.permit.push({
      permitType: '',
      validityFrom: this.date,
      validityTo: this.date,
      states: [],
      permitPhoto: new Array<UploadedFiles>(),
    });
  }
  deletePermit(permit) {
    const deleteIndex = this.vehicle.permit.indexOf(permit);
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          if (permit.permitPhoto.length) {
            // Delete uploaded files
            permit.permitPhoto.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          }
          this.vehicle.permit.splice(deleteIndex, 1);
        }
      });
  }
  addNewPuc() {
    this.vehicle.puc.push({
      pucNumber: '',
      validityFrom: this.date,
      validityTo: this.date,
      pucPhoto: new Array<UploadedFiles>(),
    });
  }
  deletePuc(puc) {
    const deleteIndex = this.vehicle.puc.indexOf(puc);
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          if (puc.pucPhoto.length) {
            // Delete uploaded files
            puc.pucPhoto.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          }
          this.vehicle.puc.splice(deleteIndex, 1);
        }
      });
  }

  onSave(form) {

    this.service.Exists(this.vehicle).subscribe(response => {
      if (response) {
        this.dialogService.open(DuplicateCheckComponent, {
          context: {
            message: 'Vehicle Already Registered!',
          },
        })
          .onClose.subscribe(confirm => {
          return false;
        });
      } else {
        if (form.valid) {
          if (this.vehicle._id) {
            this.vehicle.lastUpdationDate = new Date();
            this.service.Update(this.vehicle).subscribe(res => {
              this.router.navigate(['../vehicle'], { relativeTo: this.route });
            });
          } else {
              this.service.Save(this.vehicle).subscribe(res => {
                this.router.navigate(['../vehicle'], { relativeTo: this.route });
              });
          }
      }
    }
    });

  }

  onCancel() {
    this.router.navigate(['../vehicle'], { relativeTo: this.route });
  }
}
