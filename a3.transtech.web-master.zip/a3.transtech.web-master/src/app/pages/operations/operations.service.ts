import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { VehicleType } from './vehicle-type/vehicle-type.service';
import { HttpHeaders } from '@angular/common/http';
import 'rxjs/Rx';
import { HttpService } from '../../@core/backend/common/api/http.service';

export interface UploadedFiles {
  originalname: string;
  uploadname: string;
}

export interface Insurance {
  companyName: string;
  insuranceNumber: String;
  validityFrom: Date;
  validityTo: Date;
  insurancePhoto: Array<UploadedFiles>;
}
export interface FitnessCertificate {
  certificateNumber: String;
  validityFrom: Date;
  validityTo: Date;
  fitnessCertificatePhoto: Array<UploadedFiles>;
}
export interface Permit {
  permitType: String;
  validityFrom: Date;
  validityTo: Date;
  states: Array<String>;
  permitPhoto: Array<UploadedFiles>;
}
export interface Puc {
  pucNumber: String;
  validityFrom: Date;
  validityTo: Date;
  pucPhoto: Array<UploadedFiles>;
}
export class Vehicle {
  _id: String;
  rtoNumber: String;
  regSeries: String;
  regNumber: String;
  vehicleType: String;
  loadingCapacity: number;
  engineNumber: String;
  chassisNumber: String;
  rcBookPhoto: Array<UploadedFiles>;
  insurance: Array<Insurance>;
  puc: Array<Puc>;
  permit: Array<Permit>;
  fitnessCertificate: Array<FitnessCertificate>;
  primeRoute: String;
  otherRoute: String;
  vehiclePhoto: Array<UploadedFiles>;
  registrationDate: Date;
  lastUpdationDate: Date;
  registeredBy: Number;
  updatedBy: Number;
}

@Injectable()
export class OperationsService {

  constructor(private api: HttpService) { }

  downloadFile(file: String) {
    const body = { filename: file };

    return this.api.post('/upload/download', body, {
      responseType: 'blob',
      headers: new HttpHeaders().append('Content-Type', 'application/json'),
    });
  }
  deleteFile(file: String) {
    return this.api.post('/upload/delete', { filename: file });
  }

  GetAll(): Observable<Vehicle[]> {

    return this.api.get('/vehicle');
  }

  Get(id: string): Observable<Vehicle> {
    return this.api.get(`/vehicle/${id}`);
  }

  Save(vehicle: Vehicle): Observable<Vehicle> {
    return this.api.post('/vehicle/', vehicle);
  }

  Update(vehicle: Vehicle): Observable<Vehicle> {
    return this.api.put('/vehicle/', vehicle);
  }

  Delete(id: string): Observable<Vehicle> {
    return this.api.delete(`/vehicle/${id}`);
  }

  // Vehicle already exists or not
  Exists(vehicle: Vehicle): Observable<Vehicle> {
    return this.api.get(`/vehicle/exists/${vehicle.rtoNumber}/${vehicle.regSeries}/${vehicle.regNumber}`);
  }

  // Call Vehicle Type API to get all vehicle types
  GetAllVehicleType(): Observable<VehicleType[]> {
    return this.api.get('/vehicle/Type/all');
  }

}
