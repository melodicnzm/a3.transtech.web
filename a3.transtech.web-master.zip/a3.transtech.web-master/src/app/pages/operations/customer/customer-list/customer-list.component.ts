import { Component} from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';

import { CustomerService } from '../customer.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NbDialogService } from '@nebular/theme';
import { DeleteConfirmDialogComponent } from '../../../../common/delete-confirm-dialog/delete-confirm-dialog.component';


@Component({
  selector: 'ngx-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.scss'],
})
export class CustomerListComponent  {

  settings = {
    columns: {
      customerCode: {
        title: 'Customer Code' ,
        type: 'string',
      },
      customerName: {
        title: 'Customer Name',
        type: 'string',
      },
      email: {
        title: 'Email',
        type: 'string',
      },
      customerType: {
        title: 'Customer Type',
        type: 'string',
      },
      registeredUnderGst: {
        title: 'Registered Under GST',
        type: String,
    },
    gstNumber: {
        title: 'GST Number',
        type: String,
    },
    },
    mode: 'external',
    add: {
      confirmCreate: true,
      addButtonContent: '<i class="nb-plus"></i>',
    },
    edit: {
      confirmEdit: true,
      editButtonContent: '<i class="nb-edit"></i>',
    },
    delete: {
      confirmDelete: true,
      deleteButtonContent: '<i class="nb-trash"></i>',
    },
  };

  source: LocalDataSource = new LocalDataSource();


  constructor(private service: CustomerService,
    private router: Router,
    private route: ActivatedRoute,
    private dialogService: NbDialogService) {
    const data = this.service.GetAll();
    data.subscribe(val => this.source.load(val));
  }

  onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }

  onCreate(event): void {
    this.router.navigate(['../customer-master'], { relativeTo: this.route });
  }
  onEdit(event): void {
    this.router.navigate(['../customer-master', { id: event.data._id }], { relativeTo: this.route });
  }

  onDelete(event): void {
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete this Customer?',
      },
    })
    .onClose.subscribe(confirm => {
      if (confirm) {
        if (event.data.customerPhoto.length) {
          // Delete uploaded files
          event.data.customerPhoto.forEach(file => {
            this.service.deleteFile(file.uploadname).subscribe(x => {
            });
          });
        }
        if (event.data.agreementDetails.length) {
          // Delete uploaded files
          event.data.agreementDetails.forEach(eachAgreement => {
            eachAgreement.agreementFile.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          });
        }
        this.service.Delete(event.data._id).subscribe(response => {
          const data = this.service.GetAll();
          data.subscribe(val => this.source.load(val));
        });
      }
    });
  }


}
