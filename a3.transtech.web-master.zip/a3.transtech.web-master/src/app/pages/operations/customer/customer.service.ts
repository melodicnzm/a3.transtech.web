import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { HttpService } from '../../../@core/backend/common/api/http.service';

export interface UploadedFiles {
  originalname: string;
  uploadname: string;
}

export interface Address {
  houseNumber: string;
  buildingName: string;
  locality: string;
  area: String;
  district: String;
  state: string;
  country: string;
  pin: string;
}

export interface TransitInsurance {
    insuranceNumber: string;
    insuranceCompany: string;
    validFrom: Date;
    validUpTo: Date;
    policyType: string;
}

export interface GeneralClause {
    invoicingPeriod: string;
    creaditPeriod: string;
    creaditLimit: number;
    damageDeductionUpTo: string;
    shortageDeductionUpTo: string;
    claimSettlement: string;
    remarksAndOtherClause: string;
    validityFrom: Date;
    validityTo: Date;
}

export interface ProductDetails {
    productName: string;
    quantity: number;
    unit: string;
    value: number;
}

export interface PackingDetails {
    packingType: string;
    length: number;
    width: number;
    height: number;
    sizeOfPackage: string;
    actualWeight: string;
    volumeWeight: string;
}

export interface AllContacts {
    cname: string;
    designation: string;
    department: string;
    contact: string;
    cemail: string;
    dob: Date;
    anniversary: Date;
    authority: string;
}

export interface  Agreement {
    name: String;
    date: Date;
    validityForm: Date;
    validityTo: Date;
    agreementFile: Array<UploadedFiles>;
}

export class Customer {
    _id: string;
    customerCode: string;
    address: Array<Address>;
    customerName: string;
    customerPhoto: Array<UploadedFiles>;
    customerType: string;
    registeredUnderGst: string;
    gstNumber: string;
    hsn_sac_Number: string;
    panNumber: string;
    email: string;
    phone1: string;
    phone2: string;
    transitInsuranceDetails: Array<TransitInsurance>;
    generalClauseDetails: Array<GeneralClause>;
    productDetails: Array<ProductDetails>;
    packingDetails: Array<PackingDetails>;
    allContactsDetails: Array<AllContacts>;
    agreementDetails: Array<Agreement>;
    registrationDate: Date;
    lastUpdationDate: Date;
    registeredBy: Number;
    updatedBy: Number;
    customerCategory: string;
  }

@Injectable()
export class CustomerService {

  constructor(private api: HttpService) {}

  GetAll(): Observable<Customer[]> {

    return this.api
      .get('/customer');
  }

  Get(id: string): Observable<Customer> {
    return this.api.get(`/customer/${id}`);
  }

  Save(customer: Customer): Observable<Customer> {
    return this.api.post('/customer/', customer);
  }

  Update(customer: Customer): Observable<Customer> {
    return this.api.put('/customer/', customer);
  }

  Delete(id: string): Observable<Customer> {
    return this.api.delete(`/customer/${id}`);
  }
  // Delete uploaded file
  deleteFile(file: String) {
    return this.api.post('/upload/delete', {filename: file});
  }

  // Customer already exists or not
  Exists(customer: Customer): Observable<Customer> {
    return this.api.get(`/customer/exists/${customer.customerName}/${customer.panNumber}`);
  }
}
