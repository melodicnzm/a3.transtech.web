import { Component } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';

import { OperationsService } from '../operations.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DeleteConfirmDialogComponent } from '../../../common/delete-confirm-dialog/delete-confirm-dialog.component';
import { NbDialogService } from '@nebular/theme';

@Component({
  selector: 'ngx-vehicle-list',
  templateUrl: './vehicle-list.component.html',
  styleUrls: ['./vehicle-list.component.scss'],
})
export class VehicleListComponent {

  settings = {
    columns: {
      vehicleNumber: {
        title: 'Vehicle Number',
        type: 'string',
      },
      vehicleType: {
        title: 'Vehicle Type',
        type: 'string',
      },
      loadingCapacity: {
        title: 'Loading Capacity',
        type: 'number',
      },
      engineNumber: {
        title: 'Engine Number',
        type: 'string',
      },
      chassisNumber: {
        title: 'Chassis Number',
        type: 'string',
      },
    },
    mode: 'external',
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
    },
  };

  source: LocalDataSource = new LocalDataSource();

  constructor(private service: OperationsService,
    private router: Router,
    private route: ActivatedRoute,
    private dialogService: NbDialogService) {
    const data = this.service.GetAll();
    data.subscribe(val => {
      val.forEach(function (value) {
        const vehicleNumber = value['rtoNumber'] + ' ' + value['regSeries'] + ' ' + value['regNumber'];
        value['vehicleNumber'] = vehicleNumber;
      });
      this.source.load(val);
    });
  }

  onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }

  onCreate(event): void {
    this.router.navigate(['../vehical-master'], { relativeTo: this.route });
  }
  onEdit(event): void {
    this.router.navigate(['../vehical-master', { id: event.data._id }], { relativeTo: this.route });
  }
  onDelete(event): void {
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete this Vehicle?',
      },
    })
    .onClose.subscribe(confirm => {
      if (confirm) {
        if (event.data.rcBookPhoto.length) {
          // Delete uploaded files
          event.data.rcBookPhoto.forEach(file => {
            this.service.deleteFile(file.uploadname).subscribe(x => {
            });
          });
        }
        if (event.data.vehiclePhoto.length) {
          // Delete uploaded files
          event.data.vehiclePhoto.forEach(file => {
            this.service.deleteFile(file.uploadname).subscribe(x => {
            });
          });
        }
        if (event.data.insurance.length) {
          // Delete uploaded files
          event.data.insurance.forEach(eachInsurance => {
            eachInsurance.insurancePhoto.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          });
        }
        if (event.data.fitnessCertificate.length) {
          // Delete uploaded files
          event.data.fitnessCertificate.forEach(eachFitness => {
            eachFitness.fitnessCertificatePhoto.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          });
        }
        if (event.data.permit.length) {
          // Delete uploaded files
          event.data.permit.forEach(eachPermit => {
            eachPermit.permitPhoto.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          });
        }
        if (event.data.puc.length) {
          // Delete uploaded files
          event.data.puc.forEach(eachPuc => {
            eachPuc.pucPhoto.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          });
        }
        this.service.Delete(event.data._id).subscribe(response => {
          const data = this.service.GetAll();
          data.subscribe(val => {
            val.forEach(function (value) {
              const vehicleNumber = value['rtoNumber'] + ' ' + value['regSeries'] + ' ' + value['regNumber'];
              value['vehicleNumber'] = vehicleNumber;
            });
            this.source.load(val);
          });
        });
      }
    });
  }
}
