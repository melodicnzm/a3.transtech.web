import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { HttpService } from '../../../@core/backend/common/api/http.service';


export interface UploadedFiles {
  originalname: string;
  uploadname: string;
}

export interface Address {
  houseNumber: string;
  buildingName: string;
  locality: string;
  area: string;
  district: string;
  state: string;
  country: string;
  pin: string;
}

export interface Licence {
  licenceNumber: string;
  issuedFromState: string;
  validityFrom: Date;
  validityTo: Date;
  licencePhoto: Array<UploadedFiles>;
}

export class Owner {
  _id: string;
  ownerName: string;
  ownerPhoto: Array<UploadedFiles>;
  email: string;
  phone1: string;
  phone2: string;
  panNumber: string;
  panCardPhoto: Array<UploadedFiles>;
  adharCardPhoto: Array<UploadedFiles>;
  address: Array<Address>;
  licence: Array<Licence>;
  registrationDate: Date;
  lastUpdationDate: Date;
  registeredBy: Number;
  updatedBy: Number;
}

@Injectable()
export class OwnerService {

  constructor(private api: HttpService) { }

  GetAll(): Observable<Owner[]> {

    return this.api
      .get('/owner');
  }

  Get(id: string): Observable<Owner> {
    return this.api.get(`/owner/${id}`);
  }

  Save(owner: Owner): Observable<Owner> {
    return this.api.post('/owner/', owner);
  }

  Update(owner: Owner): Observable<Owner> {
    return this.api.put('/owner/', owner);
  }

  Delete(id: string): Observable<Owner> {
    return this.api.delete(`/owner/${id}`);
  }

  deleteFile(file: String) {
    return this.api.post('/upload/delete', { filename: file });
  }

  // Owner already exists or not
  Exists(owner: Owner): Observable<Owner> {
    return this.api.get(`/owner/exists/${owner.ownerName}/${owner.panNumber}`);
  }
}
