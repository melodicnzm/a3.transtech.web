import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { OwnerService, Owner, Address, Licence, UploadedFiles } from '../owner.service';

import { DeleteConfirmDialogComponent } from '../../../../common/delete-confirm-dialog/delete-confirm-dialog.component';
import { NbDialogService } from '@nebular/theme';
import { LocationService } from '../../location/location.service';
import { DuplicateCheckComponent } from '../../../../common/duplicate-check/duplicate-check.component';


@Component({
  selector: 'ngx-owner-master',
  templateUrl: './owner-master.component.html',
  styleUrls: ['./owner-master.component.scss'],
})
export class OwnerMasterComponent implements OnInit {
  owner: Owner;
  statesList: Array<String>;
  // define the constant url we would be uploading to.
  uri = 'http://localhost:3001/api/upload';

  submitted: Boolean;
  constructor(private service: OwnerService, private router: Router, private route: ActivatedRoute, private dialogService: NbDialogService, private location: LocationService) {
    this.owner = new Owner();
    this.owner.registrationDate = new Date();
    this.statesList = new Array<String>();
    this.owner.ownerPhoto = new Array<UploadedFiles>();
    this.owner.adharCardPhoto = new Array<UploadedFiles>();
    this.owner.panCardPhoto = new Array<UploadedFiles>();

    this.owner.address = new Array<Address>();
    this.owner.address.push({
      houseNumber: '',
      buildingName: '',
      locality: '',
      area: '',
      district: '',
      state: '',
      country: '',
      pin: '',
    });
    this.owner.licence = new Array<Licence>();
    this.owner.licence.push({
      licenceNumber: '',
      issuedFromState: '',
      validityFrom: new Date(),
      validityTo: new Date(),
      licencePhoto: new Array<UploadedFiles>(),
    });
  }

  ngOnInit() {
    const requestedOwner = this.route.snapshot.paramMap.get('id');
    if (requestedOwner) {
      this.service.Get(requestedOwner).subscribe(response => {
        this.owner = response;
      });
    }
    const states = this.location.GetStates();
    if (states) {
      states.subscribe(val => {
        this.statesList = val;
      });
    }
  }

  addNewAddress() {
    this.owner.address.push({
      houseNumber: '',
      buildingName: '',
      locality: '',
      area: '',
      district: '',
      state: '',
      country: '',
      pin: '',
    });
  }
  deleteAddress(address, event) {
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          const deleteIndex = this.owner.address.indexOf(address);
          this.owner.address.splice(deleteIndex, 1);
        }
      });
  }

  addNewLicence() {
    this.owner.licence.push({ licenceNumber: '', issuedFromState: '', validityFrom: new Date(), validityTo: new Date(), licencePhoto: new Array<UploadedFiles>() });
  }
  deleteLicence(licence) {
    const deleteIndex = this.owner.licence.indexOf(licence);
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          if (licence.licencePhoto.length) {
            // Delete uploaded files
            licence.licencePhoto.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          }
          this.owner.licence.splice(deleteIndex, 1);
        }
      });
  }

  onSave(form) {
    this.service.Exists(this.owner).subscribe(response => {
      if (response) {
        this.dialogService.open(DuplicateCheckComponent, {
          context: {
            message: 'Owner Already Registered!',
          },
        })
          .onClose.subscribe(confirm => {
            return false;
          });
      } else {
        if (form.valid) {
          if (this.owner._id) {
            this.owner.lastUpdationDate = new Date();
            this.service.Update(this.owner).subscribe(res => {
              this.router.navigate(['../owner'], { relativeTo: this.route });
            });
          } else {
            this.service.Save(this.owner).subscribe(res => {
              this.router.navigate(['../owner'], { relativeTo: this.route });
            });
          }
        }
      }
    });
  }

  onCancel() {
    this.router.navigate(['../owner'], { relativeTo: this.route });
  }

}
