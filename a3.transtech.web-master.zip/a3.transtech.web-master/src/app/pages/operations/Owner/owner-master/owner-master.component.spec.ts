import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OwnerMasterComponent } from './owner-master.component';

describe('OwnerMasterComponent', () => {
  let component: OwnerMasterComponent;
  let fixture: ComponentFixture<OwnerMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OwnerMasterComponent ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OwnerMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
