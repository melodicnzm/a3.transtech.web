import { NgModule } from '@angular/core';
import {
  NbButtonModule, NbWindowModule, NbCalendarRangeModule,
  NbCardModule, NbTooltipModule, NbAlertModule,
  NbUserModule, NbInputModule, NbActionsModule, NbCheckboxModule, NbRadioModule, NbDatepickerModule,
  NbSelectModule, NbIconModule, NbListModule, NbDialogModule,
} from '@nebular/theme';

import { ThemeModule } from '../../@theme/theme.module';
import { OperationsRoutingModule } from './operations-routing.module';
import { OperationsComponent } from './operations.component';
import { VehicalMasterComponent } from './vehicle-master/vehical-master.component';
import { OperationsService } from './operations.service';
import { ApiHttpClient } from '../../common/services/a3-httpclient.service';
import { VehicleListComponent } from './vehicle-list/vehicle-list.component';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { A3CommonModule } from '../../common/common.module';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { OwnerListComponent } from './Owner/owner-list/owner-list.component';
import { OwnerMasterComponent } from './Owner/owner-master/owner-master.component';
import { OwnerService } from './Owner/owner.service';
import { VendorListComponent } from './Vendor/vendor-list/vendor-list.component';
import { VendorMasterComponent } from './Vendor/vendor-master/vendor-master.component';
import { VendorService } from './Vendor/vendor.service';
import { ReactiveFormsModule } from '@angular/forms';
import { VehicleTypeComponent } from './vehicle-type/vehicle-type.component';
import { VehicleTypeService } from './vehicle-type/vehicle-type.service';
import { LocationMasterComponent } from './location/location-master/location-master.component';
import { LocationService } from './location/location.service';
// import the ng2-file-upload directive so we can add it to our declarations.
import { FileUploadModule } from 'ng2-file-upload';
// import { TransporterMasterComponent } from './transporter/transporter-master/transporter-master.component';
import { DriverMasterComponent } from './driver/driver-master/driver-master.component';
import { DriverListComponent } from './driver/driver-list/driver-list.component';
import { CustomerListComponent } from './customer/customer-list/customer-list.component';
import { CustomerMasterComponent } from './customer/customer-master/customer-master.component';
import { CustomerService } from './customer/customer.service';
import { DriverService } from './driver/driver.service';
import { DocketDetailsListComponent } from './docket-details/docket-details-list/docket-details-list.component';
import { DocketDetailsComponent } from './docket-details/docket-details/docket-details.component';
import { DocketDetailsService } from './docket-details/docket-details.service';
import { RetailCustomerDialogComponent } from './docket-details/retail-customer-dialog/retail-customer-dialog.component';
import { DocketInventoryService } from '../inventory/inventory.service';
import { LocationListComponent } from './location/location-list/location-list.component';
import { TransporterModule } from './transporter/transporter.module';




@NgModule({
  imports: [
    NbDialogModule.forChild(),
    NbWindowModule.forChild(),
    ThemeModule,
    NbInputModule,
    NbCardModule,
    NbButtonModule,
    NbActionsModule,
    NbUserModule,
    NbCheckboxModule,
    NbRadioModule,
    NbDatepickerModule,
    NbSelectModule,
    NbIconModule,
    NbListModule,
    Ng2SmartTableModule,
    FormsModule,
    OperationsRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    A3CommonModule,
    FileUploadModule,
    NbTooltipModule,
    NbAlertModule,
    NbCalendarRangeModule,
    TransporterModule,

  ],
  declarations: [
    OperationsComponent,
    VehicalMasterComponent,
    VehicleListComponent,
    OwnerListComponent,
    OwnerMasterComponent,
    VendorListComponent,
    VendorMasterComponent,
    VehicleTypeComponent,
    LocationMasterComponent,
    // TransporterMasterComponent,
    DriverMasterComponent,
    DriverListComponent,
    CustomerListComponent,
    CustomerMasterComponent,
    DocketDetailsListComponent,
    DocketDetailsComponent,
    RetailCustomerDialogComponent,
    LocationListComponent,
  ],
  providers: [
    ApiHttpClient,
    OperationsService,
    CustomerService,
    OwnerService,
    DriverService,
    VendorService,
    LocationService,
    VehicleTypeService,
    DocketDetailsService,
    DocketInventoryService,
  ],
  entryComponents: [
    RetailCustomerDialogComponent,
  ],
})
export class OperationModule { }
