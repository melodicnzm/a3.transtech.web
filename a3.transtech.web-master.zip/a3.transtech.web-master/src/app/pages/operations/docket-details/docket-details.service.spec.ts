import { TestBed } from '@angular/core/testing';

import { DocketDetailsService } from './docket-details.service';

describe('DocketDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DocketDetailsService = TestBed.get(DocketDetailsService);
    expect(service).toBeTruthy();
  });
});
