import { Component } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';

import { DocketDetailsService } from '../docket-details.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DeleteConfirmDialogComponent } from '../../../../common/delete-confirm-dialog/delete-confirm-dialog.component';
import { NbDialogService } from '@nebular/theme';
import { CustomerService, Customer } from '../../customer/customer.service';
import { VehicleTypeService, VehicleType } from '../../vehicle-type/vehicle-type.service';
import { OperationsService, Vehicle } from '../../operations.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'ngx-docket-details-list',
  templateUrl: './docket-details-list.component.html',
  styleUrls: ['./docket-details-list.component.scss'],
})
export class DocketDetailsListComponent {

  settings = {
    columns: {
      docketNumber: {
        title: 'Docket Number',
        type: 'string',
      },
      dateOfBooking: {
        title: 'Date Of Booking',
        type: 'date',
      },
      docketStatus: {
        title: 'Docket Status',
        type: 'string',
      },
      branchId: {
        title: 'Branch',
        type: 'string',
      },
      bookingType: {
        title: 'Booking Type',
        type: 'string',
      },
      customerId: {
        title: 'Customer Name',
        type: 'string',
      },
      vehicleId: {
        title: 'Vehicle Number',
        type: 'string',
      },
      vehicleTypeId: {
        title: 'Vehicle Type',
        type: 'string',
      },
      fromLocationId: {
        title: 'From',
        type: 'string',
      },
      toLocationId: {
        title: 'To',
        type: 'string',
      },
      bookingBasis: {
        title: 'Delivery Basis',
        type: 'string',
      },
      deliveryType: {
        title: 'Delivery Type',
        type: 'string',
      },
    },
    mode: 'external',
    add: {
      confirmCreate: true,
      addButtonContent: '<i class="nb-plus"></i>',
    },
    edit: {
      confirmEdit: true,
      editButtonContent: '<i class="nb-edit"></i>',
    },
    delete: {
      confirmDelete: true,
      deleteButtonContent: '<i class="nb-trash"></i>',
    },
  };

  source: LocalDataSource = new LocalDataSource();

  constructor(private service: DocketDetailsService,
    private customerService: CustomerService,
    private vehicleService: OperationsService,
    private vehicleTypeService: VehicleTypeService,
    private router: Router,
    private route: ActivatedRoute,
    private dialogService: NbDialogService,
    private datePipe: DatePipe) {

    this.customerService.GetAll().subscribe(customers => {

      this.vehicleTypeService.GetAll().subscribe(vehicleTypes => {
        this.vehicleService.GetAll().subscribe(vehicles => {
          this.bindDockets(customers, vehicleTypes, vehicles);
        });

      });

    });

  }

  bindDockets(customers: Array<Customer>, vehicleTypes: Array<VehicleType>, vehicles: Array<Vehicle>) {
    const data = this.service.GetAll();
    const newData = [];
    data.subscribe(val => {
      val.forEach(row => {
        const docketRow = {
          _id: row._id,
          docketNumber: row.docketNumber,
          docketStatus: '',
          branchId: row.branchId,
          bookingType: row.bookingType,
          customerId: customers.find(c => c._id === row.customerId).customerName,
          vehicleId: vehicles.find(c => c._id === row.vehicleId).regNumber,
          vehicleTypeId: vehicleTypes.find(c => c._id === row.vehicleTypeId).vehicleType,
          fromLocationId: row.fromLocationId,
          toLocationId: row.toLocationId,
          bookingBasis: row.bookingBasis,
          deliveryType: row.deliveryType,
          dateOfBooking: this.datePipe.transform(row.dateOfBooking, 'dd-MM-yyyy'),
        };
        newData.push(docketRow);
      });

      this.source.load(newData);
    });
  }

  onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }

  onCreate(event): void {
    this.router.navigate(['../docket-details'], { relativeTo: this.route });
  }
  onEdit(event): void {
    this.router.navigate(['../docket-details', { id: event.data._id }], { relativeTo: this.route });
  }
  onDelete(event): void {
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete this Docket details?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          this.service.Delete(event.data._id).subscribe(response => {
            const data = this.service.GetAll();
            data.subscribe(val => this.source.load(val));
          });
        }
      });
  }

}
