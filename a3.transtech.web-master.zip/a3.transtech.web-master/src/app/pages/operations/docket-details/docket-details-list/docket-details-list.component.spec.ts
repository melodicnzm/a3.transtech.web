import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocketDetailsListComponent } from './docket-details-list.component';

describe('DocketDetailsListComponent', () => {
  let component: DocketDetailsListComponent;
  let fixture: ComponentFixture<DocketDetailsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocketDetailsListComponent ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocketDetailsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
