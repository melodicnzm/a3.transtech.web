import { Component, OnInit, TemplateRef } from '@angular/core';

import { DocketDetailsService, DocketDetails, InvoiceDetail, PackageDetail } from '../docket-details.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DeleteConfirmDialogComponent } from '../../../../common/delete-confirm-dialog/delete-confirm-dialog.component';
import { NbDialogService } from '@nebular/theme';
import { LocationService } from '../../location/location.service';
import { DuplicateCheckComponent } from '../../../../common/duplicate-check/duplicate-check.component';
import { CustomerService, Customer, Address } from '../../customer/customer.service';
import { Vehicle, OperationsService } from '../../operations.service';
import { VehicleType, VehicleTypeService } from '../../vehicle-type/vehicle-type.service';
import { RetailCustomerDialogComponent } from '../retail-customer-dialog/retail-customer-dialog.component';
import { DocketInventoryService, DocketAssignment } from '../../../inventory/inventory.service';

@Component({
  selector: 'ngx-docket-details',
  templateUrl: './docket-details.component.html',
  styleUrls: ['./docket-details.component.scss'],
})
export class DocketDetailsComponent implements OnInit {

  public branchesList = [{ branch: 'A' }, { branch: 'B' }, { branch: 'C' }, { branch: 'D' }, { branch: 'E' }];

  docketDetails: DocketDetails;
  statesList: Array<String>;
  customersList: Array<Customer>;
  addressFromList: Array<Address>;
  addressToList: Array<Address>;
  bookingBasisList: Array<string>;
  bookingTypeList: Array<string>;
  deliveryTypeList: Array<string>;
  servicesList: Array<string>;
  vehicleNoList: Array<Vehicle>;
  sizeOfVehicleList: Array<VehicleType>;
  docketAssignmentList: Array<DocketAssignment>;

  customersListForCustomer: Array<Customer>;
  customersListForConsignor: Array<Customer>;
  customersListForConsignee: Array<Customer>;
  customersListForDeliveryTo: Array<Customer>;

  selectedCustomer: Customer = new Customer();
  selectedConsignor: Customer = new Customer();
  selectedConsignee: Customer = new Customer();
  selectedDeliveryTo: Customer = new Customer();

  selectedVehicle: VehicleType;
  selvalueAddedServices: Array<string>;
  selectedservicesList: Array<string>;
  fromState: string = '';
  toState: string = '';
  submitted: Boolean;
  constructor(private service: DocketDetailsService,
    private router: Router,
    private route: ActivatedRoute,
    private dialogService: NbDialogService,
    private customerService: CustomerService,
    private locationService: LocationService,
    private vehicleTypeService: VehicleTypeService,
    private vehicleService: OperationsService,
    private docketInventoryService: DocketInventoryService,
  ) {

    this.docketDetails = new DocketDetails();
    this.docketDetails.customerCategory = 'Register';
    this.docketDetails.sameAsConsignee = true;

    this.statesList = new Array<String>();
    this.customersList = new Array<Customer>();
    this.bookingBasisList = new Array<string>();
    this.bookingTypeList = new Array<string>();
    this.deliveryTypeList = new Array<string>();
    this.servicesList = new Array<string>();
    this.vehicleNoList = new Array<Vehicle>();
    this.sizeOfVehicleList = new Array<VehicleType>();
    this.addressFromList = new Array<Address>();
    this.addressToList = new Array<Address>();

    this.customersListForCustomer = new Array<Customer>();
    this.customersListForConsignor = new Array<Customer>();
    this.customersListForConsignee = new Array<Customer>();
    this.customersListForDeliveryTo = new Array<Customer>();

    this.docketDetails.invoiceDetail = new Array<InvoiceDetail>();
    this.docketDetails.packageDetails = new Array<PackageDetail>();

    this.docketDetails.invoiceDetail.push({
      invoiceNo: '',
      invoiceDate: new Date(),
      invoiceValue: 0,
      noOfPackages: 0,
      totalQuantity: 0,
      actualWeigth: 0,
      ewbNo: '',
    });
    this.docketDetails.packageDetails.push({
      packingType: '',
      length: 0,
      width: 0,
      height: 0,
      noOfPackages: 0,
    });

    this.docketInventoryService.GetAlldoc().subscribe(response => {
      this.docketAssignmentList = response;
    });

    this.selectedVehicle = new VehicleType();
    this.selvalueAddedServices = new Array<string>();
    this.selectedservicesList = new Array<string>();

    this.fillDDL();

  }

  ngOnInit() {
    const requestedDriver = this.route.snapshot.paramMap.get('id');
    if (requestedDriver) {
      this.service.Get(requestedDriver).subscribe(response => {
        this.docketDetails = response;
        if (this.docketDetails.invoiceDetail.length === 0) {
          this.docketDetails.invoiceDetail.push({
            invoiceNo: '',
            invoiceDate: new Date(),
            invoiceValue: 0,
            noOfPackages: 0,
            totalQuantity: 0,
            actualWeigth: 0,
            ewbNo: '',
          });
        }
        if (this.docketDetails.packageDetails.length === 0) {
          this.docketDetails.packageDetails.push({
            packingType: '',
            length: 0,
            width: 0,
            height: 0,
            noOfPackages: 0,
          });
        }

        this.changeCustomerCategory();
        this.changeCustomer();
        this.changeConsignor();
        this.changeConsignee();
        this.changeFromPin();
        this.changeToPin();
        this.changeVehicleType();

        this.docketDetails.valueAddedServices
          .forEach(f => this.servicesList.splice(this.servicesList.findIndex(i => i === f), 1));
        this.docketDetails.valueAddedServices
          .forEach(f => this.selectedservicesList.push(f));

      });
    }

  }

  fillDDL() {
    this.locationService.GetStates().subscribe(val => {
      this.statesList = val;
    });
    this.customerService.GetAll().subscribe(val => {
      this.customersList = val;
      this.changeCustomerCategory();
    });
    this.vehicleService.GetAll().subscribe(val => {
      this.vehicleNoList = val;
    });
    this.vehicleTypeService.GetAll().subscribe(val => {
      this.sizeOfVehicleList = val;
    });

    this.bookingTypeList = Array<string>();
    this.bookingTypeList.push('Direct Delivery Docket');
    this.bookingTypeList.push('Additional Delivery Docket');

    this.deliveryTypeList = Array<string>();
    this.deliveryTypeList.push('Normal Delivery');
    this.deliveryTypeList.push('Site Deliver');

    this.fillServicesList();
  }

  fillBookingBasis() {
    this.bookingBasisList = Array<string>();
    if (this.docketDetails.customerCategory === 'Register') {
      this.bookingBasisList.push('Contract');
      this.bookingBasisList.push('Spot');
    } else {
      this.bookingBasisList.push('Paid');
      this.bookingBasisList.push('To-Pay ');
    }
  }

  fillServicesList() {
    this.servicesList = Array<string>();
    this.servicesList.push('COD');
    this.servicesList.push('DACC');
    this.servicesList.push('FRAGILE MATERILA');
    this.servicesList.push('LIQUID HANDLING');
    this.servicesList.push('HAZARDOUS MATERIAL');
    this.servicesList.push('ODC MATERIAL');
  }

  changeCustomerCategory() {
    if (this.docketDetails.customerCategory === 'Retail') {
      this.customersListForCustomer = this.customersList.filter(f => f.customerCategory === this.docketDetails.customerCategory);
    } else {
      this.customersListForCustomer = this.customersList.filter(f => f.customerCategory === this.docketDetails.customerCategory || f.customerCategory === '' || f.customerCategory === null);
    }
    this.fillBookingBasis();
  }

  changeCustomer() {
    if (this.docketDetails.customerId) {
      const selectedCustomers = this.customersList.filter(f => f._id === this.docketDetails.customerId);
      if (selectedCustomers.length > 0) {
        this.selectedCustomer = selectedCustomers[0];
      }
    }
  }

  changeConsignee() {
    if (this.docketDetails.consigneeId) {
      const selectedCustomers = this.customersList.filter(f => f._id === this.docketDetails.consigneeId);
      if (selectedCustomers.length > 0) {
        this.selectedConsignee = selectedCustomers[0];
      }
      this.changeSameAsConsignee();
    }
    // docketDetails.fromLocationId === docketDetails.toLocationId
  }
  changeConsignor() {
    if (this.docketDetails.consignorId) {
      const selectedCustomers = this.customersList.filter(f => f._id === this.docketDetails.consignorId);
      if (selectedCustomers.length > 0) {
        this.selectedConsignor = selectedCustomers[0];
        this.addressFromList = selectedCustomers[0].address;
      }
    }
  }
  changeDeliveryTo() {
    if (this.docketDetails.deliveryToId) {
      const selectedCustomers = this.customersList.filter(f => f._id === this.docketDetails.deliveryToId);
      if (selectedCustomers.length > 0) {
        this.selectedDeliveryTo = selectedCustomers[0];
        this.addressToList = selectedCustomers[0].address;
      }
    }
  }
  changeSameAsConsignee() {
    if (this.docketDetails.sameAsConsignee === true) {
      this.docketDetails.deliveryToId = this.docketDetails.consigneeId;
      this.changeDeliveryTo();
    }
  }
  changeFromPin() {
    if (this.docketDetails.fromLocationId)
      this.fromState = this.addressFromList.find(f => f.pin === this.docketDetails.fromLocationId).state;
  }
  changeToPin() {
    if (this.docketDetails.toLocationId)
      this.toState = this.addressToList.find(f => f.pin === this.docketDetails.toLocationId).state;
  }
  setTotalInvoiceFields() {
    this.docketDetails.totalInvoiceNo = this.docketDetails.invoiceDetail.length;
    this.docketDetails.totalInvoiceValue = this.docketDetails.invoiceDetail.reduce((sum, item) => sum + item.invoiceValue, 0);
    this.docketDetails.totalNoOfPackages = this.docketDetails.invoiceDetail.reduce((sum, item) => sum + item.noOfPackages, 0);
    this.docketDetails.totalActualWeigth = this.docketDetails.invoiceDetail.reduce((sum, item) => sum + item.actualWeigth, 0);
  }
  changeNoofPackages() {
    const totalNoOfPackages = this.docketDetails.packageDetails.reduce((sum, item) => sum + item.noOfPackages, 0);
    if (this.docketDetails.totalNoOfPackages > totalNoOfPackages)
      return true;
    else
      return false;
  }
  changeVehicleNo() {
    const selectedVehicle = this.vehicleNoList.filter(f => f._id === this.docketDetails.vehicleId)[0];
    this.docketDetails.vehicleTypeId = this.sizeOfVehicleList.filter(f => f.vehicleType === selectedVehicle.vehicleType)[0]._id;
    this.changeVehicleType();
  }
  changeVehicleType() {
    this.selectedVehicle = this.sizeOfVehicleList.filter(f => f._id === this.docketDetails.vehicleTypeId)[0];
  }

  addValueAddedService() {
    this.selvalueAddedServices.forEach(f => this.selectedservicesList.push(f));
    this.selvalueAddedServices.forEach(f => this.servicesList.splice(this.servicesList.findIndex(i => i === f), 1));
  }
  removeValueAddedService() {
    this.docketDetails.valueAddedServices.forEach(f => this.servicesList.push(f));
    this.docketDetails.valueAddedServices.forEach(f => this.selectedservicesList.splice(this.selectedservicesList.findIndex(i => i === f), 1));
  }

  addNewInvoiceDetail() {
    this.docketDetails.invoiceDetail.push({ invoiceNo: '', invoiceDate: new Date(), invoiceValue: 0, noOfPackages: 0, totalQuantity: 0, actualWeigth: 0, ewbNo: '' });
  }
  deleteInvoiceDetail(invoiceDetail, event) {
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          const deleteIndex = this.docketDetails.invoiceDetail.indexOf(invoiceDetail);
          this.docketDetails.invoiceDetail.splice(deleteIndex, 1);
        }
      });
  }

  addNewPackageDetails() {
    this.docketDetails.packageDetails.push({ packingType: '', length: 0, width: 0, height: 0, noOfPackages: 0 });
  }
  deletePackageDetails(packageDetails) {
    const deleteIndex = this.docketDetails.packageDetails.indexOf(packageDetails);
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          this.docketDetails.packageDetails.splice(deleteIndex, 1);
        }
      });
  }

  onSave(form, dialog: TemplateRef<any>) {

    const totalNoOfPackages = this.docketDetails.packageDetails.reduce((sum, item) => sum + item.noOfPackages, 0);
    if (this.docketDetails.totalNoOfPackages !== totalNoOfPackages) {
      this.dialogService.open(DuplicateCheckComponent, {
        context: {
          message: 'Total number of packages not match with packages.',
        },
      })
        .onClose.subscribe(confirm => {
          return false;
        });
      return false;
    }

    this.docketDetails.valueAddedServices = this.selectedservicesList;
    this.service.Exists(this.docketDetails).subscribe(response => {
      if (response) {
        this.dialogService.open(DuplicateCheckComponent, {
          context: {
            message: 'Docket details Already Registered!',
          },
        })
          .onClose.subscribe(confirm => {
            return false;
          });
      } else {
        let isValidDocketNumber = false;
        const selDocketAssignment = this.docketAssignmentList.filter(f => f.branch = this.docketDetails.branchId);
        if (selDocketAssignment.length > 0) {
          if (selDocketAssignment[0].seriesFrom <= this.docketDetails.docketNumber && selDocketAssignment[0].seriesTo >= this.docketDetails.docketNumber) {
            isValidDocketNumber = true;
          } else {
            this.dialogService.open(
              dialog,
              {
                context: 'Docket number is valid between ' + selDocketAssignment[0].seriesFrom + ' to ' + selDocketAssignment[0].seriesTo,
                hasBackdrop: false,
              });
          }
        }

        if (form.valid && isValidDocketNumber) {
          if (this.docketDetails._id) {
            // this.docketDetails.lastUpdationDate = new Date();
            this.service.Update(this.docketDetails).subscribe(res => {
              this.router.navigate(['../docket-details-list'], { relativeTo: this.route });
            });
          } else {
            this.service.Save(this.docketDetails).subscribe(res => {
              this.router.navigate(['../docket-details-list'], { relativeTo: this.route });
            });
          }
        }
      }
    });
  }

  onCancel() {
    this.router.navigate(['../docket-details-list'], { relativeTo: this.route });
  }

  OnCreateRetailCustomer(type, customerCategory): void {
    this.dialogService.open(RetailCustomerDialogComponent, {
      context: {
        customerCategory: customerCategory,
      },
    })
      .onClose.subscribe((newCustomer: Customer) => {
        if (newCustomer) {
          this.refreshCustomers(type, newCustomer);
        }
      });
  }
  refreshCustomers(type, selCustomer) {
    const customers = this.customerService.GetAll();
    if (customers) {
      customers.subscribe(val => {
        this.customersList = val;
        if (type === 'Customer') {
          this.changeCustomerCategory();
          const newCustomer = this.customersList.filter(f => f.customerCode === selCustomer.customerCode);
          if (newCustomer.length > 0) {
            this.docketDetails.customerId = newCustomer[0]._id;
            this.changeCustomer();
          }
        } else if (type === 'Consignor') {
          const newCustomer = this.customersList.filter(f => f.customerCode === selCustomer.customerCode);
          if (newCustomer.length > 0) {
            this.docketDetails.consignorId = newCustomer[0]._id;
            this.changeConsignor();
          }
        } else if (type === 'Consignee') {
          const newCustomer = this.customersList.filter(f => f.customerCode === selCustomer.customerCode);
          if (newCustomer.length > 0) {
            this.docketDetails.consigneeId = newCustomer[0]._id;
            this.changeConsignee();
          }
        } else if (type === 'DeliveryTo') {
          const newCustomer = this.customersList.filter(f => f.customerCode === selCustomer.customerCode);
          if (newCustomer.length > 0) {
            this.docketDetails.deliveryToId = newCustomer[0]._id;
            this.changeDeliveryTo();
          }
        }
      });
    }
  }


}
