import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocketDetailsComponent } from './docket-details.component';

describe('DocketDetailsComponent', () => {
  let component: DocketDetailsComponent;
  let fixture: ComponentFixture<DocketDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocketDetailsComponent ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocketDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
