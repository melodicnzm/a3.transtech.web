import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailCustomerDialogComponent } from './retail-customer-dialog.component';

describe('RetailCustomerDialogComponent', () => {
  let component: RetailCustomerDialogComponent;
  let fixture: ComponentFixture<RetailCustomerDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetailCustomerDialogComponent ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetailCustomerDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
