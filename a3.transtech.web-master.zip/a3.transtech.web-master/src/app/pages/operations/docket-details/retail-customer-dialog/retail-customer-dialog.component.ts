import { Component, OnInit, Input } from '@angular/core';
import { NbDialogRef, NbDialogService } from '@nebular/theme';
import { Customer, CustomerService, UploadedFiles, Address, TransitInsurance, GeneralClause, PackingDetails, Agreement } from '../../customer/customer.service';
import { DeleteConfirmDialogComponent } from '../../../../common/delete-confirm-dialog/delete-confirm-dialog.component';
import { DuplicateCheckComponent } from '../../../../common/duplicate-check/duplicate-check.component';

@Component({
  selector: 'ngx-retail-customer-dialog',
  templateUrl: './retail-customer-dialog.component.html',
  styleUrls: ['./retail-customer-dialog.component.scss'],
})
export class RetailCustomerDialogComponent implements OnInit {

  @Input() customerCategory: string;
  date: Date;
  customer: Customer;
  constructor(
    protected ref: NbDialogRef<RetailCustomerDialogComponent>,
    private service: CustomerService,
    private dialogService: NbDialogService,
  ) {
    this.customer = new Customer();
    const random = Math.floor(Math.random() * (999999 - 100000)) + 100000;
    this.customer.customerCode = 'R_' + random.toString();
    this.customer.registeredBy = 0;
    this.customer.updatedBy = 0;
    this.customer.customerCategory = this.customerCategory ? this.customerCategory : 'Retail';
    this.customer.customerPhoto = new Array<UploadedFiles>();
    this.customer.address = new Array<Address>();
    this.customer.address.push({ houseNumber: '', buildingName: '', locality: '', area: '', district: '', state: '', country: '', pin: '' });

    this.customer.transitInsuranceDetails = new Array<TransitInsurance>();

    this.customer.generalClauseDetails = new Array<GeneralClause>();

    this.customer.packingDetails = new Array<PackingDetails>();

    this.customer.agreementDetails = new Array<Agreement>();

  }

  ngOnInit() {
  }

  addNewAddress() {
    this.customer.address.push({
      houseNumber: '',
      buildingName: '',
      locality: '',
      area: '',
      district: '',
      state: '',
      country: '',
      pin: '',
    });
  }
  deleteAddress(address, event) {
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          const deleteIndex = this.customer.address.indexOf(address);
          this.customer.address.splice(deleteIndex, 1);
        }
      });
  }
  addNewTransitInsurance() {
    this.customer.transitInsuranceDetails.push({
      insuranceNumber: '',
      insuranceCompany: '',
      validFrom: this.date,
      validUpTo: this.date,
      policyType: '',
    });
  }
  deleteTransitInsurance(transitInsuranceDetails, event) {
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          const deleteIndex = this.customer.transitInsuranceDetails.indexOf(transitInsuranceDetails);
          this.customer.transitInsuranceDetails.splice(deleteIndex, 1);
        }
      });
  }
  addNewGeneralClause() {
    this.customer.generalClauseDetails.push({
      invoicingPeriod: '',
      creaditPeriod: '',
      creaditLimit: Number(),
      damageDeductionUpTo: '',
      shortageDeductionUpTo: '',
      claimSettlement: '',
      remarksAndOtherClause: '',
      validityFrom: this.date,
      validityTo: this.date,
    });
  }
  deleteGeneralClause(generalClauseDetails, event) {
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          const deleteIndex = this.customer.generalClauseDetails.indexOf(generalClauseDetails);
          this.customer.generalClauseDetails.splice(deleteIndex, 1);
        }
      });
  }
  addNewPackingDetails() {
    this.customer.packingDetails.push({
      packingType: '', length: Number(), width: Number(), height: Number(), sizeOfPackage: '',
      actualWeight: '', volumeWeight: '',
    });
  }
  deletePackingDetails(packingDetails, event) {
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          const deleteIndex = this.customer.packingDetails.indexOf(packingDetails);
          this.customer.packingDetails.splice(deleteIndex, 1);
        }
      });
  }
  addNewAgreement() {
    this.customer.agreementDetails.push({
      name: '',
      date: new Date(),
      validityForm: new Date(),
      validityTo: new Date(),
      agreementFile: new Array<UploadedFiles>(),
    });
  }
  deleteAgreement(agreementDetails, event) {
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          if (agreementDetails.agreementFile.length) {
            // Delete uploaded files
            agreementDetails.agreementFile.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          }
          const deleteIndex = this.customer.agreementDetails.indexOf(agreementDetails);
          this.customer.agreementDetails.splice(deleteIndex, 1);
        }
      });
  }
  onSave(form) {
    this.service.Exists(this.customer).subscribe(response => {
      if (response) {
        this.dialogService.open(DuplicateCheckComponent, {
          context: {
            message: 'Customer Already Registered!',
          },
        })
          .onClose.subscribe(confirm => {
            return false;
          });
      } else {
        if (form.valid) {
          if (this.customer._id) {
            this.customer.lastUpdationDate = new Date();
            this.service.Update(this.customer).subscribe(resp => {
              this.ref.close(this.customer);
            });
          } else {
            this.service.Save(this.customer).subscribe(resp => {
              this.ref.close(this.customer);
            });
          }
        }
      }
    });

  }

  cancel() {
    this.ref.close(null);
  }

  submit() {
    this.ref.close(this.customer);
  }

}
