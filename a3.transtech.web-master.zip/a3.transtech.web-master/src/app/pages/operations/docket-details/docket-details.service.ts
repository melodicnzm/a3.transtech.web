import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { HttpService } from '../../../@core/backend/common/api/http.service';


export class DocketDetails {
  _id: string;
  branchId: string;
  docketNumber: number;
  dateOfBooking: Date;

  customerCategory: string;
  customerId: string;
  consignorId: string;
  consigneeId: string;
  sameAsConsignee: boolean;
  deliveryToId: string;

  fromLocationId: string;
  toLocationId: string;
  bookingDate: Date;
  exceptedDeliveryDate: Date;
  bookingBasis: string;
  bookingType: string;
  deliveryType: string;

  invoiceDetail: Array<InvoiceDetail>;
  totalInvoiceNo: number;
  totalInvoiceValue: number;
  totalNoOfPackages: number;
  totalActualWeigth: number;
  totalChargeableWeight: number;

  saidToContain: string;
  packageDetails: Array<PackageDetail>;
  valueAddedServices: Array<string>;
  vehicleId: string;
  vehicleTypeId: string;

  registrationDate: Date;
  lastUpdationDate: Date;
  registeredBy: number;
  updatedBy: number;
}

export class InvoiceDetail {
  invoiceNo: string;
  invoiceDate: Date;
  invoiceValue: number;
  noOfPackages: number;
  totalQuantity: number;
  actualWeigth: number;
  ewbNo: string;
}

export class PackageDetail {
  packingType: string;
  length: number;
  width: number;
  height: number;
  noOfPackages: number;
}

@Injectable()
export class DocketDetailsService {

  constructor(private api: HttpService) { }

  GetAll(): Observable<DocketDetails[]> {
    return this.api.get('/docketEntry');
  }

  Get(id: string): Observable<DocketDetails> {
    return this.api.get(`/docketEntry/${id}`);
  }

  Save(docketDetails: DocketDetails): Observable<DocketDetails> {
    return this.api.post('/docketEntry/', docketDetails);
  }

  Update(docketDetails: DocketDetails): Observable<DocketDetails> {
    return this.api.put('/docketEntry/', docketDetails);
  }

  Delete(id: string): Observable<DocketDetails> {
    return this.api.delete(`/docketEntry/${id}`);
  }

  deleteFile(file: String) {
    return this.api.post('/upload/delete', { filename: file });
  }

  // DocketDetails already exists or not
  Exists(docketDetails: DocketDetails): Observable<DocketDetails> {
    return this.api.get(`/docketEntry/exists/${docketDetails.docketNumber}}`);
  }
}
