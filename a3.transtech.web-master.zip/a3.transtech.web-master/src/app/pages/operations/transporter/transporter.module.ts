import { NgModule } from '@angular/core';
import {
  NbButtonModule, NbWindowModule, NbCalendarRangeModule,
  NbCardModule, NbTooltipModule, NbAlertModule,
  NbUserModule, NbInputModule, NbActionsModule, NbCheckboxModule, NbRadioModule, NbDatepickerModule,
  NbSelectModule, NbIconModule, NbListModule, NbDialogModule,
} from '@nebular/theme';


// import the ng2-file-upload directive so we can add it to our declarations.
import { FileUploadModule } from 'ng2-file-upload';
import { DatePipe } from '@angular/common';
import { ThemeModule } from '../../../@theme/theme.module';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { A3CommonModule } from '../../../common/common.module';
import { ApiHttpClient } from '../../../common/services/a3-httpclient.service';
import { TransporterMasterComponent } from './transporter-master/transporter-master.component';
import { OperationsService } from '../operations.service';
import { TransporterService } from './transporter.service';

@NgModule({
  imports: [
    NbDialogModule.forChild(),
    NbWindowModule.forChild(),
    ThemeModule,
    NbInputModule,
    NbCardModule,
    NbButtonModule,
    NbActionsModule,
    NbUserModule,
    NbCheckboxModule,
    NbRadioModule,
    NbDatepickerModule,
    NbSelectModule,
    NbIconModule,
    NbListModule,
    Ng2SmartTableModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    A3CommonModule,
    FileUploadModule,
    NbTooltipModule,
    NbAlertModule,
    NbCalendarRangeModule,
  ],
  declarations: [
    TransporterMasterComponent,
  ],
  providers: [
    ApiHttpClient,
    OperationsService,
    TransporterService,
    DatePipe,
  ],
})
export class TransporterModule { }
