import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { HttpService } from '../../../@core/backend/common/api/http.service';

export interface UploadedFiles {
  originalname: string;
  uploadname: string;
}

export interface Address {
  houseNumber: string;
  buildingName: string;
  locality: string;
  area: String;
  district: String;
  state: string;
  country: string;
  pin: string;
}

export interface BankDetails {
  bankName: string;
  branch: string;
  bankAddress: string;
  accountNumber: number;
  accountType: string;
  bankPhoneNumber: string;
  mircCode: number;
  ifscNumber: string;
  beneficiaryName: string;
  email: string;
  phone: string;
  beneficiaryAddress: string;
  cancelledChequePhoto: Array<UploadedFiles>;
}

export class Transporter {
  _id: string;
  transporterName: String;
  profilePicture: Array<UploadedFiles>;
  email: string;
  phone1: string;
  phone2: string;
  logo: Array<UploadedFiles>;
  webProfile: string;
  panNumber: string;
  panPhoto: Array<UploadedFiles>;
  gstNumber: string;
  companyType: string;
  address: Array<Address>;
  bankDetails: Array<BankDetails>;
  registrationDate: Date;
  lastUpdationDate: Date;
  registeredBy: Number;
  updatedBy: Number;
}


@Injectable()
export class TransporterService {

  constructor(private api: HttpService) { }

  GetAll(): Observable<Transporter[]> {
    return this.api.get('/transporter');
  }
  Get(id: string): Observable<Transporter> {
    return this.api.get(`/transporter/${id}`);
  }
  Save(transporter: Transporter): Observable<Transporter> {
    return this.api.post('/transporter/', transporter);
  }
  deleteFile(file: String) {
    return this.api.post('/upload/delete', { filename: file });
  }
}
