import { Component } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';

import { ActivatedRoute, Router } from '@angular/router';
import { TransporterService, Transporter, Address, BankDetails, UploadedFiles } from '../transporter.service';
import { NbDialogService } from '@nebular/theme';
import { DeleteConfirmDialogComponent } from '../../../../common/delete-confirm-dialog/delete-confirm-dialog.component';
import { InitUserService } from '../../../../@theme/services/init-user.service';


@Component({
  selector: 'ngx-transporter-master',
  templateUrl: './transporter-master.component.html',
  styleUrls: ['./transporter-master.component.scss'],
  providers: [TransporterService],
})
export class TransporterMasterComponent {
  // define the constant url we would be uploading to.
  uri = 'http://localhost:3001/api/upload';

  source: LocalDataSource = new LocalDataSource();

  submitted: Boolean;
  transporter: Transporter;
  isStartupPage: boolean = false;
  constructor(private service: TransporterService,
    private router: Router,
    private route: ActivatedRoute,
    private dialogService: NbDialogService,
    protected initUserService: InitUserService,
  ) {
    this.transporter = new Transporter();
    this.transporter.profilePicture = new Array<UploadedFiles>();
    this.transporter.logo = new Array<UploadedFiles>();
    this.transporter.panPhoto = new Array<UploadedFiles>();
    this.transporter.address = new Array<Address>();
    this.transporter.address.push({
      houseNumber: '',
      buildingName: '',
      locality: '',
      area: '',
      district: '',
      state: '',
      country: '',
      pin: '',
    });

    this.transporter.bankDetails = new Array<BankDetails>();
    this.transporter.bankDetails.push({
      bankName: '',
      branch: '',
      bankAddress: '',
      accountNumber: Number(),
      accountType: '',
      bankPhoneNumber: '',
      mircCode: Number(),
      ifscNumber: '',
      beneficiaryName: '',
      email: '',
      phone: '',
      beneficiaryAddress: '',
      cancelledChequePhoto: new Array<UploadedFiles>(),
    });

    this.route.data.subscribe((v) => v ? this.isStartupPage = v.isStartupPage : this.isStartupPage = false);

    this.initUserService.initCurrentUser().subscribe(user => {
      this.service.GetAll().subscribe(transporters => {
        const transport = transporters.filter(f => f.registeredBy === user.id);
        if (transport.length > 0)
          return this.router.navigateByUrl('/pages/dashboard');
      });
    });

  }

  addNewAddress() {
    this.transporter.address.push({
      houseNumber: '',
      buildingName: '',
      locality: '',
      area: '',
      district: '',
      state: '',
      country: '',
      pin: '' });
  }
  deleteAddress(address) {
    const deleteIndex = this.transporter.address.indexOf(address);
    this.transporter.address.splice(deleteIndex, 1);
  }

  addNewBankDetails() {
    this.transporter.bankDetails.push({
      bankName: '',
      branch: '',
      bankAddress: '',
      accountNumber: Number(),
      accountType: '',
      bankPhoneNumber: '',
      mircCode: Number(),
      ifscNumber: '',
      beneficiaryName: '',
      email: '',
      phone: '',
      beneficiaryAddress: '',
      cancelledChequePhoto: new Array<UploadedFiles>(),
    });
  }

  deleteBankDetails(bankDetails) {
    const deleteIndex = this.transporter.bankDetails.indexOf(bankDetails);
    this.dialogService.open(DeleteConfirmDialogComponent, {
      context: {
        message: 'Are you sure you Want to delete this Transporter?',
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          if (bankDetails.cancelledChequePhoto.length) {
            // Delete uploaded files
            bankDetails.cancelledChequePhoto.forEach(file => {
              this.service.deleteFile(file.uploadname).subscribe(x => {
              });
            });
          }
          // Delete Bank
          this.transporter.bankDetails.splice(deleteIndex, 1);
        }
      });

  }

  onSave() {
    this.service.Save(this.transporter).subscribe(response => {
      this.router.navigate(['../../dashboard'], { relativeTo: this.route });
    });
  }

  onCancel() {
    this.router.navigate(['.../dashboard'], { relativeTo: this.route });
  }

  onStartupSave(next) {
    this.service.Save(this.transporter).subscribe(response => {
      if (next === true)
        this.router.navigate(['../business-unit/' + response._id], { relativeTo: this.route });
    });
  }

}
