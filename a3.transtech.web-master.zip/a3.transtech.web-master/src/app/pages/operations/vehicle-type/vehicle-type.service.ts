import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpService } from '../../../@core/backend/common/api/http.service';


export class VehicleType {
  _id: string;
  vehicleType: string;
  capacity: number;
  description: string;
}

@Injectable()
export class VehicleTypeService {

  constructor(private api: HttpService) { }

  GetAll(): Observable<VehicleType[]> {

    return this.api.get('/vehicle/Type/all');
  }

  Get(id: string): Observable<VehicleType> {
    return this.api.get(`/vehicle/Type/${id}`);
  }

  Save(vehicle: VehicleType): Observable<VehicleType> {
    return this.api.post('/vehicle/Type/', vehicle);
  }

  Update(vehicle: VehicleType): Observable<VehicleType> {
    return this.api.put('/vehicle/Type/', vehicle);
  }

  Delete(id: string): Observable<VehicleType> {
    return this.api.delete(`/vehicle/Type/${id}`);
  }

  // Vehicle already exists or not
  Exists(vehicle: VehicleType): Observable<VehicleType> {
    return this.api.get(`/vehicle/Type/exists/${vehicle.vehicleType}/${vehicle.capacity}`);
  }
}
