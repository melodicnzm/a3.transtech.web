import { Component } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';

import { VehicleTypeService } from './vehicle-type.service';

import { NbDialogService } from '@nebular/theme';
import { DuplicateCheckComponent } from '../../../common/duplicate-check/duplicate-check.component';



@Component({
  selector: 'ngx-vehicle-type',
  templateUrl: './vehicle-type.component.html',
  styleUrls: ['./vehicle-type.component.scss'],
})
export class VehicleTypeComponent  {

  settings = {
    columns: {
      vehicleType: {
        title: 'Vehicle Type',
        type: 'string',
      },
      capacity: {
        title: 'Capacity (Ton)',
        type: 'number',
      },
      description: {
        title: 'Description',
        type: 'string',
      },
    },
    mode : 'inline',
    add: {
      confirmCreate: true,
      addButtonContent: '<i class="nb-plus"></i>',
      createButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
    },
    edit: {
      confirmSave: true,
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
  };

  source: LocalDataSource = new LocalDataSource();

  constructor(private service: VehicleTypeService,
    private dialogService: NbDialogService) {
    const data = this.service.GetAll();
    data.subscribe(val => this.source.load(val));
  }

  onCreate(event): void {
    this.service.Exists(event.newData).subscribe(response => {
      if (response) {
        this.dialogService.open(DuplicateCheckComponent, {
          context: {
            message: 'Vehicle type already registered!',
          },
        })
          .onClose.subscribe(confirm => {
          return false;
        });
      } else {
        this.service.Save(event.newData).subscribe(x => {
          if (x && x._id) {
            event.confirm.resolve(event.newData);
          } else {
            // show error message in dialog box, with only ok button.
            event.confirm.reject();
          }
        });
       }
    });
  }

  onEdit(event): void {

     this.service.Exists(event.newData).subscribe(response => {
      if (response) {
        this.dialogService.open(DuplicateCheckComponent, {
          context: {
            message: 'Vehicle type already registered!',
          },
        })
          .onClose.subscribe(confirm => {
          return false;
        });
      } else {
        if (event.data._id) {
          this.service.Update(event.newData).subscribe(res => {
            event.confirm.resolve(event.newData);
          });
        } else {
          this.service.Save(event.data).subscribe(res => {
            event.confirm.reject();
          });
        }
       }
    });
     }

  onDelete(event): void {
    this.service.Delete(event.data._id).subscribe(response => {
      const data = this.service.GetAll();
      data.subscribe(val => this.source.load(val));
    });
}
}
