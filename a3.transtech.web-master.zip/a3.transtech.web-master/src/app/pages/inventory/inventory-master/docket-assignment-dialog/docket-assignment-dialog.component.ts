import { Component, OnInit } from '@angular/core';
import { NbDialogRef } from '@nebular/theme';
import { DocketInventoryService, DocketInventory, DocketAssignment} from '../../inventory.service';


@Component({
  selector: 'ngx-docket-assignment-dialog',
  templateUrl: './docket-assignment-dialog.component.html',
  styleUrls: ['./docket-assignment-dialog.component.scss'],
})
export class DocketAssignmentDialogComponent implements OnInit {

  public branchList = [{ branch : 'A'}, { branch : 'B'}, { branch : 'C'}, { branch : 'D'}, { branch : 'E'}];

  docketAssignment: DocketAssignment;
  docketList: Array<DocketInventory> = [];

  constructor(protected ref: NbDialogRef<DocketAssignmentDialogComponent>,
      private service: DocketInventoryService) {
      if (!this.docketAssignment)
           this.docketAssignment = new DocketAssignment();
  }

  ngOnInit() {
    const docketTypeData = this.service.GetAll();
    if (docketTypeData) {
      docketTypeData.subscribe(val => {
        val.unshift({ _id: '0', bookNo: 0, seriesFrom: 0, seriesTo: 0 , date: new Date() });
        this.docketList = val;
      });
    }
  }

  changeSeries() {
    this.docketList.forEach(value => {
      if (value.bookNo === this.docketAssignment.bookNo) {
        this.docketAssignment.seriesFrom = value.seriesFrom;
        this.docketAssignment.seriesTo = value.seriesTo;
      }
    });
  }

  cancel() {
    this.ref.close(null);
  }

  submit() {
    this.ref.close(this.docketAssignment);
  }
}
