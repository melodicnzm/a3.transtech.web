import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocketAssignmentDialogComponent } from './docket-assignment-dialog.component';

describe('DocketAssignmentDialogComponent', () => {
  let component: DocketAssignmentDialogComponent;
  let fixture: ComponentFixture<DocketAssignmentDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocketAssignmentDialogComponent ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocketAssignmentDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
