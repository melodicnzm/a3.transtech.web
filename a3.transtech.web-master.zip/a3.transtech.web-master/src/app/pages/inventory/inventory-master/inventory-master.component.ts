import { ChangeDetectionStrategy, Component} from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';

import { DocketInventoryService, DocketInventory, DocketAssignment, Search} from '../inventory.service';
import { DocketAssignmentDialogComponent } from '../inventory-master/docket-assignment-dialog/docket-assignment-dialog.component';
import { DocketInventoryDialogComponent } from '../inventory-master/docket-inventory-dialog/docket-inventory-dialog.component';

import { NbDialogService } from '@nebular/theme';

@Component({
  selector: 'ngx-inventory-master',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './inventory-master.component.html',
  styleUrls: ['./inventory-master.component.scss'],
})

export class InventoryMasterComponent   {

  docketAssignment: DocketAssignment;
  docketInventory: DocketInventory;
  search: Search;


  settings = {
    columns: {
      date: {
        title: 'Date',
        type: 'Date',
      },
      bookNo: {
        title: 'Book Number',
        type: 'number',
      },
      seriesFrom: {
        title: 'Series From',
        type: 'number',
      },
      seriesTo: {
        title: 'Series To',
        type: 'number',
      },
    },
    mode : 'external',
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
    },
  };
  assignSettings = {
    columns: {

      branch: {
        title: 'Branch',
        type: 'string',
      },
      bookNo: {
        title: 'Book Number',
        type: 'number',
      },
      seriesFrom: {
        title: 'Series From',
        type: 'number',
      },
      seriesTo: {
        title: 'Series To',
        type: 'number',
      },
      date: {
        title: 'Date',
        type: 'Date',
      },
    },
    mode: 'external',
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
    },
  };

  source: LocalDataSource = new LocalDataSource();
  source2: LocalDataSource = new LocalDataSource();

  constructor(private service: DocketInventoryService,
  private dialogService: NbDialogService) {
    this.search = new Search();
    this.docketAssignment = new DocketAssignment();
  const data = this.service.GetAll();
  data.subscribe(val => {
          this.source.load(val);
      },
   );

   const docdata = this.service.GetAlldoc();
        docdata.subscribe(dval => {
                this.source2.load(dval);
            },
        );

  }

  OnSearch(search) {
    const data = this.service.Search(this.search);
     data.subscribe(val => {
          this.source.load(val);
      },
   );
  }

  OnSearchDoc(search) {
    const data = this.service.Searchdoc(this.search);
     data.subscribe(val => {
         this.source.refresh();
          this.source2.load(val);
      },
   );
  }

  onCreate(event): void {
    this.dialogService.open(DocketInventoryDialogComponent)
    .onClose.subscribe(confirm => {
      if (confirm) {
        this.service.Save(confirm).subscribe(response => {
          this.source.refresh();
          const data = this.service.GetAll();
          data.subscribe(val => this.source.load(val));
        });
      }
    });
  }

  onCreateDocketAssignment(event): void {
    this.dialogService.open(DocketAssignmentDialogComponent)
    .onClose.subscribe(confirm => {
      if (confirm) {
        this.service.Savedoc(confirm).subscribe(response => {
          this.source.refresh();
          const data = this.service.GetAlldoc();
          data.subscribe(val => this.source2.load(val));
        });
      }
    });
  }


   onEdit(event): void {
    this.dialogService.open(DocketInventoryDialogComponent, {
      context: {
        docketInventory: event.data,
      },
    })
    .onClose.subscribe(confirm => {
        if (event.data._id) {
          this.service.Update(event.data).subscribe(response => {
          });
        } else {
          this.service.Savedoc(event.data).subscribe(response => {
            event.confirm.reject();
          });
        }
     // }
    });
  }

   onEditDocketAssignment(event): void {
    this.dialogService.open(DocketAssignmentDialogComponent, {
      context: {
        docketAssignment: event.data,
      },
    })
    .onClose.subscribe(confirm => {
        if (event.data._id) {
          this.service.Updatedoc(event.newData).subscribe(response => {
          });
        } else {
          this.service.Savedoc(event.data).subscribe(response => {
            event.confirm.reject();
          });
        }
    });
  }

   onDelete(event): void {
   this.service.Delete(event.data._id).subscribe(response => {
     const data = this.service.GetAll();
     data.subscribe(val => this.source.load(val));
   });
  }

  onDeleteDocketAssignment(event): void {
    this.service.Deletedoc(event.data._id).subscribe(response => {
      const data = this.service.GetAlldoc();
      data.subscribe(val => this.source2.load(val));
    });
   }
}
