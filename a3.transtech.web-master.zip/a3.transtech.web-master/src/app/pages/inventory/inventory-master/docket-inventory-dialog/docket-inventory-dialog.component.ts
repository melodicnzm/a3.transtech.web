import { Component } from '@angular/core';
import { NbDialogRef } from '@nebular/theme';
import { DocketInventory} from '../../inventory.service';


@Component({
  selector: 'ngx-docket-inventory-dialog',
  templateUrl: './docket-inventory-dialog.component.html',
  styleUrls: ['./docket-inventory-dialog.component.scss'],
})
export class DocketInventoryDialogComponent  {

  docketInventory: DocketInventory;

  docketList: Array<DocketInventory> = [];
  constructor(protected ref: NbDialogRef<DocketInventoryDialogComponent>) {
      if (!this.docketInventory)
           this.docketInventory = new DocketInventory();

  }

  cancel() {
    this.ref.close(null);
  }

  submit() {
    this.ref.close(this.docketInventory);
  }

}
