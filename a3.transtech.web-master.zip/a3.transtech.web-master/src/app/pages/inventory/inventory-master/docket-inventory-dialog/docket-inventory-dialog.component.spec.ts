import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocketInventoryDialogComponent } from './docket-inventory-dialog.component';

describe('DocketInventoryDialogComponent', () => {
  let component: DocketInventoryDialogComponent;
  let fixture: ComponentFixture<DocketInventoryDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocketInventoryDialogComponent ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocketInventoryDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
