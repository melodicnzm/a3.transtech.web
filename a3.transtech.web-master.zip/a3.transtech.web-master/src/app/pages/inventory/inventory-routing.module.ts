import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { InventoryComponent } from './inventory.component';
import {InventoryMasterComponent} from './inventory-master/inventory-master.component';



const routes: Routes = [{
  path: '',
  component: InventoryComponent,
  children: [
    {
      path: 'inventory',
      component: InventoryMasterComponent,
    },
    {
      path: 'LetterHead',
    },
    {
      path: 'Voucher',
    },
  ],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InventoryRoutingModule {
}

