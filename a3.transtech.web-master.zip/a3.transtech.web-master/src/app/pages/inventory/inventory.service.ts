import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiHttpClient } from '../../common/services/a3-httpclient.service';

export class DocketInventory {
    _id: string;
    date: Date;
    bookNo: number;
    seriesFrom: number;
    seriesTo: number;
    }

    export class DocketAssignment {
      _id: string;
      branch: string;
      date: Date;
      bookNo: number;
      seriesFrom: number;
      seriesTo: number;
      status: string ;
    }

    export class Search {
      fromDate: Date;
      toDate: Date;
      status: String;
    }


@Injectable()
export class DocketInventoryService {

    constructor(private http: ApiHttpClient) { }

    GetAll(): Observable<DocketInventory[]> {

        return this.http
          .get<DocketInventory[]>('/docketInventory');
      }

      Get(id: string): Observable<DocketInventory> {
        return this.http.get<DocketInventory>(`/docketInventory/${id}`);
      }

      Save(docketInventory: DocketInventory): Observable<DocketInventory> {
        return this.http.post<DocketInventory>('/docketInventory/', docketInventory);
      }

      Update(docketInventory: DocketInventory): Observable<DocketInventory> {
        return this.http.put<DocketInventory>('/docketInventory/', docketInventory);
      }

      Delete(id: string): Observable<DocketInventory> {
        return this.http.delete<DocketInventory>(`/docketInventory/${id}`);
      }

      GetAlldoc(): Observable<DocketAssignment[]> {

        return this.http
          .get<DocketAssignment[]>('/docketAssignment');
      }

      Getdoc(id: string): Observable<DocketAssignment> {
        return this.http.get<DocketAssignment>(`/docketAssignment/${id}`);
      }

      Savedoc(docketAssignment: DocketAssignment): Observable<DocketAssignment> {
        return this.http.post<DocketAssignment>('/docketAssignment/', docketAssignment);
      }

      Updatedoc(docketAssignment: DocketAssignment): Observable<DocketAssignment> {
        return this.http.put<DocketAssignment>('/docketAssignment/', docketAssignment);
      }

      Deletedoc(id: string): Observable<DocketAssignment> {
        return this.http.delete<DocketAssignment>(`/docketAssignment/${id}`);
      }

      Search(search: Search): Observable<DocketInventory[]> {
        return this.http.post<DocketInventory[]>('/docketInventory/search/', search);
      }

      Searchdoc(search: Search): Observable<DocketAssignment[]> {
        return this.http.post<DocketAssignment[]>('/docketAssignment/search/', search);
      }
}



