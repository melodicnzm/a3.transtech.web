import { NgModule } from '@angular/core';
import {
  NbButtonModule,
  NbCardModule,
  NbUserModule, NbInputModule, NbActionsModule, NbCheckboxModule, NbRadioModule, NbDatepickerModule, NbSelectModule,
   NbIconModule, NbListModule, NbDialogModule, NbTabsetModule, NbDialogService,
} from '@nebular/theme';

import { ThemeModule } from '../../@theme/theme.module';
import { InventoryRoutingModule } from './inventory-routing.module';
import { InventoryComponent } from './inventory.component';


import { DocketInventoryService } from './inventory.service';
import { ApiHttpClient } from '../../common/services/a3-httpclient.service';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { A3CommonModule } from '../../common/common.module';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { InventoryMasterComponent } from './inventory-master/inventory-master.component';
import { DocketAssignmentDialogComponent } from './inventory-master/docket-assignment-dialog/docket-assignment-dialog.component';
import { DocketInventoryDialogComponent } from './inventory-master/docket-inventory-dialog/docket-inventory-dialog.component';

@NgModule({
  imports: [
    NbDialogModule.forChild(),
    ThemeModule,
    NbInputModule,
    NbCardModule,
    NbButtonModule,
    NbActionsModule,
    NbUserModule,
    NbCheckboxModule,
    NbRadioModule,
    NbDatepickerModule,
    NbSelectModule,
    NbIconModule,
    NbListModule,
    Ng2SmartTableModule,
    NbTabsetModule,
    InventoryRoutingModule,
    FormsModule,
    A3CommonModule,
    ReactiveFormsModule,
  ],
  declarations: [
    InventoryComponent,
    InventoryMasterComponent,
    DocketAssignmentDialogComponent,
    DocketInventoryDialogComponent,
  ],
  providers: [
    ApiHttpClient,
    DocketInventoryService,
    NbDialogService,
  ],
  entryComponents: [
    DocketAssignmentDialogComponent,
    DocketInventoryDialogComponent,
  ],
})
export class InventoryModule { }
