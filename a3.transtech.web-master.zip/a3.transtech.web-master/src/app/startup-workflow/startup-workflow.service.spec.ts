import { TestBed } from '@angular/core/testing';

import { StartupWorkflowService } from './startup-workflow.service';

describe('StartupWorkflowService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: StartupWorkflowService = TestBed.get(StartupWorkflowService);
    expect(service).toBeTruthy();
  });
});
