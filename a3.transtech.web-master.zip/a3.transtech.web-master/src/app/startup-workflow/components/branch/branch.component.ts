import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { TreeComponent, TreeModel } from 'angular-tree-component';
import { ITreeNode } from 'angular-tree-component/dist/defs/api';
import { Branch, BranchService } from '../../branch.service';

@Component({
  selector: 'ngx-branch',
  templateUrl: './branch.component.html',
  styleUrls: ['./branch.component.scss'],
})

export class BranchComponent implements OnInit, AfterViewInit {
  @ViewChild('tree', { static: false }) treeComponent: TreeComponent;
  treeModel: TreeModel;
  branches: Array<Branch>;
  transporterId: string;

  nodes: Array<any> = [{
    _id: '',
    branchId: this.generateId(),
    branchName: '',
    parentBranchId: '',
    children: [],
  }];

  options = {
    allowDrag: true,
    allowDrop: true,
  };

  constructor(private branchService: BranchService,
    private router: Router,
    private route: ActivatedRoute) {

  }

  ngOnInit() {
    this.transporterId = this.route.snapshot.paramMap.get('transid');
    if (this.transporterId) {
      this.bindData();
    }
    // this.transporterService.Get(this.transporterId).subscribe(response => {
    //   this.transporter = response;
    // });
  }

  ngAfterViewInit() {
    this.treeModel = this.treeComponent.treeModel;
  }

  bindData() {
    this.branchService.GetAllBranches(this.transporterId).subscribe(response => {
      this.branches = response;

      const parentBranch = this.branches.filter((f) => f.parentBranchId === undefined);

      if (parentBranch.length > 0) {
        this.nodes = [];
        parentBranch.forEach(b => {
          this.nodes.push({
            _id: b._id,
            branchId: b.branchId,
            branchName: b.branchName,
            parentBranchId: b.parentBranchId,
            children: this.getChildBranches(b.branchId),
          });
        });

        this.treeModel.update();
        this.treeModel.expandAll();
      }
    });

  }
  getChildBranches(branchId): Array<any> {
    const childBranches = this.branches.filter((f) => f.parentBranchId === branchId);
    const nodes = new Array<any>();
    childBranches.forEach(b => {
      nodes.push({
        _id: b._id,
        branchId: b.branchId,
        branchName: b.branchName,
        parentBranchId: b.parentBranchId,
        children: this.getChildBranches(b.branchId),
      });
    });
    return nodes;
  }

  addNode(selectedNode: ITreeNode) {
    if (selectedNode && selectedNode.data) {
      selectedNode.data.children.push({
        branchId: this.generateId(),
        branchName: '',
        parentBranchId: selectedNode.data.branchId,
        children: [],
      });

      this.treeModel.update();
      selectedNode.expand();
    }
  }

  removeNode(selectedNode: ITreeNode) {
    if (selectedNode.isRoot) {
      return;
    }
    const index = selectedNode.parent.data.children.findIndex(x => x.branchId === selectedNode.data.branchId);
    selectedNode.parent.data.children.splice(index, 1);
    this.treeModel.update();
  }

  onEvent($event) {

  }
  onSave() {
    this.saveBranch().subscribe(response => {
      this.bindData();
    });
  }

  convertintoEntity() {
    this.branches = new Array<Branch>();
    if (this.nodes.length > 0) {
      this.nodes.forEach(n => {

        const branch = new Branch();
        branch.transporterId = this.transporterId;
        branch._id = n._id;
        branch.branchId = n.branchId;
        branch.branchName = n.branchName;
        if (n.parentBranchId)
          branch.parentBranchId = n.parentbranchId;
        this.branches.push(branch);

        this.getChildData(n.children);
      });
    }

  }
  getChildData(childBranch) {
    if (childBranch.length > 0) {
      childBranch.forEach(n => {
        const branch = new Branch();
        branch.transporterId = this.transporterId;
        branch._id = n._id;
        branch.branchId = n.branchId;
        branch.branchName = n.branchName;
        if (n.parentBranchId)
          branch.parentBranchId = n.parentBranchId;
        this.branches.push(branch);

        if (n.children.length > 0)
          this.getChildData(n.children);

      });
    }
  }

  onSaveAndNext() {
    this.saveBranch().subscribe(response => {
      this.router.navigate(['startup/create-user/' + this.transporterId]);
    });
  }

  saveBranch(): Observable<Array<Branch>> {
    this.convertintoEntity();
    return this.branchService.SaveAll(this.branches);
  }

  private generateId(): string {
    return 'B_' + Math.floor(Math.random() * 999999);
  }
}
