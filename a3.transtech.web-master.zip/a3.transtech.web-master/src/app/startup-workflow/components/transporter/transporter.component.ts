import { Component, OnInit } from '@angular/core';
import { StartupWorkflowService, Transporter } from '../../startup-workflow.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'ngx-transporter',
  templateUrl: './transporter.component.html',
  styleUrls: ['./transporter.component.scss'],
})
export class TransporterComponent implements OnInit {

  public transporter: Transporter;

  constructor(private workflowService: StartupWorkflowService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.transporter = this.workflowService.getTransporter();
  }

  onSave() {
    this.saveTransporter();
  }

  onSaveAndNext() {
    this.saveTransporter().subscribe(response => {
      this.router.navigate(['../business-unit'], { relativeTo: this.route });
    });
  }

  saveTransporter(): Observable<Transporter> {
    return this.workflowService.Save(this.transporter);
  }
}
