import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.scss'],
})
export class RoleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
