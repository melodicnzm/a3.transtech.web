import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-startup-workflow',
  styleUrls: ['./startup-workflow.component.scss'],
  templateUrl: './startup-workflow.component.html',
})
export class StartupWorkflowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
