import { Component, OnInit } from '@angular/core';
import { NbDialogRef } from '@nebular/theme';
import { BaseUser } from '../../../../@core/interfaces/common/users';
import { Branch } from '../../../branch.service';

@Component({
  selector: 'ngx-user-dialog',
  templateUrl: './user-dialog.component.html',
  styleUrls: ['./user-dialog.component.scss'],
})
export class UserDialogComponent implements OnInit {

  idEdit: boolean;
  user: BaseUser;
  branches: Array<Branch>;
  transporterId: string;

  constructor(protected ref: NbDialogRef<UserDialogComponent>) {

  }

  ngOnInit() {

    if (!this.idEdit) {
      this.user = {
        _id: '0',
        firstName: '',
        lastName: '',
        login: '',
        email: '',
        password: '',
        phone: 0,
        branchId: '',
        userType: 'guest',
        transporterId: this.transporterId,
      };
    }
  }

  cancel() {
    this.ref.close(null);
  }

  submit() {
    this.ref.close(this.user);
  }
}
