import { Component, OnInit } from '@angular/core';
import { StartupWorkflowService } from '../../startup-workflow.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { LocalDataSource } from 'ng2-smart-table';
import { NbDialogService } from '@nebular/theme';
import { UserData, BaseUser } from '../../../@core/interfaces/common/users';
import { UserDialogComponent } from './user-dialog/user-dialog.component';
import { BranchService, Branch } from '../../branch.service';

@Component({
  selector: 'ngx-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss'],
})
export class UserComponent implements OnInit {

  settings = {
    columns: {
      branchName: {
        title: 'Branch Name',
        type: 'string',
      },
      firstName: {
        title: 'First Name',
        type: 'string',
      },
      lastName: {
        title: 'Last Name',
        type: 'string',
      },
      email: {
        title: 'Email',
        type: 'string',
      },
      phone: {
        title: 'Mobile',
        type: 'string',
      },
    },
    mode: 'external',
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
    },
  };

  source: LocalDataSource = new LocalDataSource();
  private user: BaseUser;
  transporterId: string;
  branches: Array<Branch>;

  constructor(private workflowService: StartupWorkflowService,
    private router: Router,
    private route: ActivatedRoute,
    private branchService: BranchService,
    private userService: UserData,
    private dialogService: NbDialogService) {
  }

  bindUsers() {
    const data = this.workflowService.GetAllUsers();
    data.subscribe(val => {
      val.items.forEach(d => {
        const branchObj = this.branches.filter(b => b._id === d.branchId);
        if (branchObj && branchObj.length > 0)
          d.branchName = branchObj[0].branchName;
      });
      this.source.load(val.items);
    });
  }

  ngOnInit() {
    this.transporterId = this.route.snapshot.paramMap.get('transid');

    if (this.transporterId) {
      this.branchService.GetAllBranches(this.transporterId).subscribe(response => {
        this.branches = response;
        this.bindUsers();
      });
    }
  }

  onSave() {
    this.saveUser(this.user);
  }

  onSaveAndNext() {
    this.saveUser(this.user).subscribe(response => {
      this.router.navigate(['../define-roles'], { relativeTo: this.route });
    });
  }

  saveUser(user): Observable<BaseUser> {
    const random = 'p_' + Math.floor(Math.random() * (999999 - 100000)) + 100000;
    user.login = user.firstName + ' ' + user.lastName;
    user.password = random;
    user.userType = 'guest';
    return this.userService.createBaseUser(user);
  }
  onCreate(event): void {
    this.dialogService.open(UserDialogComponent, {
      context: {
        transporterId: this.transporterId,
        idEdit: false,
        branches: this.branches,
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          this.saveUser(confirm).subscribe(response => {
            this.bindUsers();
          });
        }
      });
  }
  onEdit(event): void {
    this.dialogService.open(UserDialogComponent, {
      context: {
        transporterId: this.transporterId,
        user: event.data,
        idEdit: true,
        branches: this.branches,
      },
    })
      .onClose.subscribe(confirm => {
        if (confirm) {
          this.userService.updateBaseUser(confirm).subscribe(response => {
            this.bindUsers();
          });
        }
      });
  }
  onDelete(event): void {
    this.userService.delete(event.data.id).subscribe(response => {
      this.source.refresh();
      this.bindUsers();
    });

  }

  onFinish() {
    this.router.navigate(['/'], { relativeTo: this.route });
  }
}
