import { Component, OnInit } from '@angular/core';
import { Transporter } from '../../startup-workflow.service';

@Component({
  selector: 'ngx-register-transporter',
  templateUrl: './register-transporter.component.html',
  styleUrls: ['./register-transporter.component.scss'],
})
export class RegisterTransporterComponent implements OnInit {

  transporter: Transporter;
  constructor() {
    this.transporter = {
      profile: {
        name: 'sss',
      },
    };
  }

  ngOnInit() {
  }

}
