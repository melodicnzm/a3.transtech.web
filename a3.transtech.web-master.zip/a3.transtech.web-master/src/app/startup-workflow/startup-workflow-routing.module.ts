
import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { StartupWorkflowComponent } from './components/startup-workflow.component';
import { RegisterTransporterComponent } from './components/register-transporter/register-transporter.component';
import { BranchComponent } from './components/branch/branch.component';
import { UserComponent } from './components/user/user.component';
import { RoleComponent } from './components/role/role.component';
import { TransporterMasterComponent } from '../pages/operations/transporter/transporter-master/transporter-master.component';


const routes: Routes = [{
  path: '',
  component: StartupWorkflowComponent,
  children: [
    {
      path: 'transporter',
      component: TransporterMasterComponent,
      data: { isStartupPage: true },
    },
    {
      path: 'business-unit/:transid',
      component: BranchComponent,
    },
    {
      path: 'create-user/:transid',
      component: UserComponent,
    },
    {
      path: 'define-roles',
      component: RoleComponent,
    },
    {
      path: 'register-transporter',
      component: RegisterTransporterComponent,
    },
  ],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class StartupWorkflowRoutingModule {

}
