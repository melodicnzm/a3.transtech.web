import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpService } from '../@core/backend/common/api/http.service';

export class Branch {
    _id: string;
    transporterId: string;
    branchId: string;
    branchName: string;
    parentBranchId: string;
}

@Injectable()
export class BranchService {

    constructor(private api: HttpService) { }

    GetAll(): Observable<Branch[]> {
        return this.api.get('/branch');
    }
    Get(id: string): Observable<Branch> {
        return this.api.get(`/branch/${id}`);
    }
    GetAllBranches(transporterId: string): Observable<Branch[]> {
        return this.api.get(`/branch/transporter/${transporterId}`);
    }
    Save(branch: Branch): Observable<Branch> {
        return this.api.post('/branch/', branch);
    }
    SaveAll(branches: Array<Branch>): Observable<Array<Branch>> {
        return this.api.post('/branch/all/', branches);
    }
    deleteFile(file: String) {
        return this.api.post('/upload/delete', { filename: file });
    }
}
