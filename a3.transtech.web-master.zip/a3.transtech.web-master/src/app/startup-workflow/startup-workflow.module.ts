import { NgModule, ModuleWithProviders } from '@angular/core';
import { RegisterTransporterComponent } from './components/register-transporter/register-transporter.component';
import { StartupWorkflowRoutingModule } from './startup-workflow-routing.module';
import { StartupWorkflowComponent } from './components/startup-workflow.component';
import { NbIconModule,
  NbLayoutModule,
  NbCardModule,
  NbAlertModule,
  NbCheckboxModule,
  NbInputModule,
  NbButtonModule,
  NbStepperModule,
  NbActionsModule,
  NbUserModule,
  NbRadioModule,
  NbDatepickerModule,
  NbSelectModule,
  NbListModule,
  NbDialogService,
  NbTabsetModule } from '@nebular/theme';
import { TransporterComponent } from './components/transporter/transporter.component';
import { BranchComponent } from './components/branch/branch.component';
import { UserComponent } from './components/user/user.component';
import { RoleComponent } from './components/role/role.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StartupWorkflowService } from './startup-workflow.service';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { TreeModule } from 'angular-tree-component';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { SmartTableDatepickerRenderComponent } from './components/user/editor';
import { TransporterModule } from '../pages/operations/transporter/transporter.module';
import { BranchService } from './branch.service';
import { UserDialogComponent } from './components/user/user-dialog/user-dialog.component';
import { ThemeModule } from '../@theme/theme.module';

const NB_MODULES = [
  NbIconModule,
  NbLayoutModule,
  NbCardModule,
  NbAlertModule,
  NbCheckboxModule,
  NbInputModule,
  NbButtonModule,
  NbStepperModule,
  ThemeModule,
  NbActionsModule,
  NbUserModule,
  NbRadioModule,
  NbDatepickerModule,
  NbSelectModule,
  NbListModule,
  Ng2SmartTableModule,
  NbTabsetModule,
];

@NgModule({
  imports: [
    TransporterModule,

    TreeModule,
    FormsModule,
    Ng2SmartTableModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    StartupWorkflowRoutingModule,
    ReactiveFormsModule,
    ...NB_MODULES,
  ],
  declarations: [
    StartupWorkflowComponent,
    RegisterTransporterComponent,
    SmartTableDatepickerRenderComponent,
    TransporterComponent,
    BranchComponent,
    UserComponent,
    RoleComponent,
    UserDialogComponent,

  ],
  providers: [
    StartupWorkflowService,
    NbDialogService,
    BranchService,
  ],
  entryComponents: [
    UserDialogComponent,
  ],
})
export class StartupWorkflowModule {
  static forRoot(): ModuleWithProviders {
    return <ModuleWithProviders>{
      ngModule: StartupWorkflowModule,
    };
  }
}
