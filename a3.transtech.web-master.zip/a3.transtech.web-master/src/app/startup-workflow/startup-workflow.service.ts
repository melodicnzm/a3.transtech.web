import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpService } from '../@core/backend/common/api/http.service';

@Injectable({
  providedIn: 'root',
})
export class StartupWorkflowService {

  GetAllUsers(): Observable<any> {
    return this.api.get('/users/');
  }

  GetAllUserswithParam(filters): Observable<any> {
    return this.api.get('/users?' + filters);
  }

  Save(vehicle: Transporter): Observable<Transporter> {
    // return this.api.post<Transporter>("/transporter/", vehicle);
    return new Observable<Transporter>((observer) => {
      observer.next(this.transporter);
      observer.complete();
    });
  }

  transporter: Transporter;
  constructor(private api: HttpService) {

    this.transporter = {
      profile: {
        name: 'sss',
      },
    };
  }

  public getTransporter(): Transporter {
    return this.transporter;
  }
}

export interface TransporterProfile {
  name: string;
}

export class Transporter {
  profile: TransporterProfile;
}
