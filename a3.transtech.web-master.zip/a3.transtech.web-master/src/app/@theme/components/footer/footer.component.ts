/*
 * Copyright (c) Akveo 2019. All Rights Reserved.
 * Licensed under the Single Application / Multi Application License.
 * See LICENSE_SINGLE_APP / LICENSE_MULTI_APP in the 'docs' folder for license information on type of purchased license.
 */

import { Component } from '@angular/core';

@Component({
  selector: 'ngx-footer',
  styleUrls: ['./footer.component.scss'],
  template: `
  <span class="created-by">Copyright © All rights reserved | <b>
  <a href="https://a3transtech.com" target="_blank">A3 Transtech</a></b> {{ currentYear }}</span>
    <div class="socials">
      <a href="https://www.facebook.com/A3-Transtech-112521056999480/?modal=admin_todo_tour" target="_blank" class="ion ion-social-facebook"></a>
      <a href="https://twitter.com/A3Transtech" target="_blank" class="ion ion-social-twitter"></a>
      <a href="https://www.instagram.com/a3transtech/" target="_blank" class="ion ion-social-instagram"></a>
    </div>
  `,
})
export class FooterComponent {
  get currentYear(): number {
    return new Date().getFullYear();
  }
}
